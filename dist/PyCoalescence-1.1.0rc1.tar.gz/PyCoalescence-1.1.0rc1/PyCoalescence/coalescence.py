"""
Contains the Coalescence and Map classes as part of the PyCoalescence Project.

Operations involve setting up and running simulations, plus basic tree generation after simulations have been completed.
"""

import logging
import subprocess
import warnings
import os
import numpy as np
import types
import copy
import sys
from system_operations import execute_log_info, set_logging_method, mod_directory

global sqlite_import, config_success
try:
	if sys.version_info[0] is 3:
		import configparser as ConfigParser
	else:
		import ConfigParser
	config_success = True
except ImportError as ie:
	ConfigParser = None
	warnings.warn("Could not import ConfigParser. Config options disabled: " + ie.message)
	config_success = False

try:
	NumberTypes = (types.IntType, types.LongType, types.FloatType, types.ComplexType)
except AttributeError:
	# No support for complex numbers compile
	NumberTypes = (int, float)

try:
	from osgeo import gdal
except ImportError as ie:
	gdal = None
	warnings.warn("Problem importing  (gdal) modules. " + str(ie))

try:
	try:
		import sqlite3
	except ImportError:
		# Python 3 compatibility
		import sqlite as sqlite3
	sqlite_import = True
	import coal_analyse as ca
except ImportError as ie:
	sqlite_import = False
	ca = None
	sqlite3 = None
	warnings.warn("Problem importing sqlite module " + str(ie))

__author__ = "Samuel Thompson"
__copyright__ = "Copyright 2016, The PyCoalescence Project"
__credits__ = ["Samuel Thompson"]
__license__ = "BSD-3"
__version__ = "1.0.1"
__maintainer__ = "Samuel Thompson"
__email__ = "thompsonsed@gmail.com"


class Map:
	"""A class for the map object, containing the file name and the variables associated with this map object."""

	def __init__(self, is_sample=None):
		self.file_name = None
		self.x_size = 0
		self.y_size = 0
		self.x_offset = 0
		self.y_offset = 0
		self.x_res = 0
		self.y_res = 0
		self.dimensions_set = False
		self.is_sample = is_sample

	def set_dimensions(self, file_name=None, x_size=None, y_size=None, x_offset=None, y_offset=None):
		""" Sets the dimensions and file for the Map object

		:param str file_name: the location of the map object (a csv or tif file). If None, required that file_name is already provided.
		:param int x_size: the x dimension
		:param int y_size: the y dimension
		:param int x_offset: the x offset from the north-west corner
		:param int y_offset: the y offset from the north-west corner
		:return: None
		"""
		if file_name is not None:
			self.file_name = file_name
		elif self.file_name is None:
			raise RuntimeError("No file name provided when trying to set dimensions.")
		if (y_size is None and x_size is not None) or (x_size is None and y_size is not None):
			warnings.warn(
				"Attempt to specify size, but x_size or y_size not provided. Trying to read dimensions from file.",
				RuntimeWarning)
			x_size = None
			y_size = None
		if x_size is None:
			self.x_size, self.y_size, self.x_offset, self.y_offset, self.x_res, self.y_res = self.read_dimensions()
		else:
			self.x_size = x_size
			self.y_size = y_size
			# Make sure the x_offsets are set if not none, otherwise default to 0
			if x_offset is not None:
				self.x_offset = x_offset
			else:
				self.x_offset = 0
			if y_offset is not None:
				self.y_offset = y_offset
			else:
				self.y_offset = 0
			self.dimensions_set = True

	def set_sample(self, is_sample):
		"""Set the is_sample attribute to true if this is a sample mask rather than an offset map

		:param bool is_sample: indicates this is a sample mask rather than offset map
		"""
		if is_sample:
			self.x_offset = 0
			self.y_offset = 0
			self.is_sample = True

	def check_map(self):
		"""Checks that the dimensions for the map have been set and that the map file exists"""
		if not (isinstance(self.x_size, NumberTypes) and isinstance(self.y_size, NumberTypes) and
					isinstance(self.x_offset, NumberTypes) and isinstance(self.y_offset, NumberTypes) and
					isinstance(self.x_res, NumberTypes) and isinstance(self.y_res, NumberTypes)):
			raise ValueError(
				"values not set as numbers in " + self.file_name + ": " + str(self.x_size) + ", " + str(self.y_size) +
				" | " + str(self.x_offset) + ", " + str(self.y_offset) +
				" | " + str(self.x_res) + ", " + str(self.y_res))
		if not self.dimensions_set:
			err = "Dimensions for map file " + str(self.file_name) + " not set."
			raise RuntimeError(err)
		if not os.path.exists(self.file_name) and self.file_name is not "null":
			err = "Map file " + self.file_name + " does not exist. Check that this is an absolute path or disable map " \
												 "file check"
			IOError(err)

	def read_dimensions(self):
		"""
		Return a list containing the geospatial coordinate system for the file.

		:return: a list containing [0] x, [1] y, [2] upper left x, [3] upper left y, [4] x resolution, [5] y resolution
		"""
		if gdal is None:
			raise ImportError("Gdal module not imported correctly: cannot read tif files")
		if ".tif" not in self.file_name:
			raise IOError("tif file not detected - dimensions cannot be read: " + self.file_name)
		if not os.path.exists(self.file_name):
			raise IOError(
				"File " + str(self.file_name) + " does not exist or is not accessible. Check read/write access.")
		ds = gdal.Open(self.file_name)
		x = ds.RasterXSize
		y = ds.RasterYSize
		ulx, xres, xskew, uly, yskew, yres = ds.GetGeoTransform()
		return [x, y, ulx, uly, xres, yres]

	def get_dimensions(self):
		"""
		Calls read_dimensions() if dimensions have not been read, or reads stored information.
		:return: a list containing [0] x, [1] y, [2] upper left x, [3] upper left y, [4] x resolution, [5] y resolution
		.. note:: the returned list will contain the x and y offset values instead of the ulx and uly values if the
				  dimensions have already been set (i.e. self.x_size != 0 and self.y_size != 0)
		"""
		if self.x_size is 0 and self.y_size is 0:
			return self.read_dimensions()
		else:
			return [self.x_size, self.y_size, self.x_offset, self.y_offset, self.x_res, self.y_res]

	def calculate_scale(self, file_scaled):
		"""
		Calculates the scale of map object from the supplied file_scaled.

		:param str/Map file_scaled: the path to the file to calculate the scale.
		:return: the scale (of the x dimension)
		"""
		if isinstance(file_scaled, str):
			scaled = Map()
			scaled.set_dimensions(file_scaled)
		elif isinstance(file_scaled, Map):
			scaled = file_scaled
		else:
			raise ValueError("supplied argument is not a string or Map type: " + str(file_scaled))
		src = np.array(self.read_dimensions())
		dst = np.array(scaled.read_dimensions())
		# Check that each of the dimensions matches
		out = dst[4:] / src[4:]
		if out[0] != out[1]:
			warnings.warn('Inequal scaling of x and y dimensions. Check map files.')
		return out[0]

	def calculate_offset(self, file_offset):
		"""
		Calculates the offset of the map object from the supplied file_offset.

		:param str/Map file_offset: the path to the file to calculate the offset.
			Can also be a Map object with the filename contained.

		:return: the offset x and y (at the resolution of the file_home) in integers
		"""
		if isinstance(file_offset, str):
			offset = Map()
			offset.set_dimensions(file_offset)
		elif isinstance(file_offset, Map):
			offset = file_offset
		else:
			raise ValueError("file_offset type must be Map or str. Type provided: " + str(type(file_offset)))
		try:
			src = np.array(self.read_dimensions())
		except IOError:
			src = np.array(self.get_dimensions())
		try:
			off = np.array(offset.read_dimensions())
		except IOError:
			off = np.array(offset.get_dimensions())
		diff = [int(round(x, 0)) for x in (src[2:4] - off[2:4]) / src[4:]]
		return diff

	def get_x_y(self):
		"""
		Simply returns the x and y dimension of the file.

		:return: the x and y dimensions
		"""
		if self.dimensions_set:
			return [self.x_size, self.y_size]
		return self.read_dimensions()[:2]


class Coalescence:
	"""
	A class containing routines to set up and run simulations, including detecting map dimensions from tif files.
	"""

	def __init__(self, coalescence_simulator=None, logging_level=logging.INFO,
				 log_output=None, **kwargs):
		"""
		Initialise with optional locations of the Coal and Speciation executables.

		:param str coalescence_simulator: location of the coalescence simulator executable
		:param int logging_level: the minimal level of logging to display
		:param string log_output: a file to output log data to. Use None for writing to console.
		:param kwargs: additional keyword arguments to supply to logging.basicConfig()
		"""
		# All the parameters used for the simulation
		set_logging_method(logging_level=logging_level, output=log_output)
		self.output_directory = ""
		self.coalescence_simulator = ""
		self.map_config = ''
		self.full_config_file = ''
		self.is_setup = False
		self.is_setup_param = False
		self.is_setup_map = False
		self.is_setup_complete = False
		self.job_num = 0
		self.grid_x_size = 0
		self.grid_y_size = 0
		self.fine_map = Map()
		self.coarse_map = Map()
		self.sample_map = Map()
		self.coarse_scale = 1
		self.min_speciation_rate = 0
		self.zfat = 2
		self.deme = 1
		self.sample_size = 1
		self.max_time = 100
		self.lambda_value = 1  # the relative cost of moving through non-matrix
		self.job_type = 0
		self.min_num_species = 1
		self.pristine_fine_map_file = ""
		self.pristine_coarse_map_file = ""
		# amount of forest change that occurs before pristine state (there will be a jump to pristine at the pristine time
		self.forest_change_param = 0
		self.pristine_forest = 1  # The number of generations ago a forest was pristine
		self.dispersal = 0
		self.time_config_file = ""
		self.setup(coalescence_simulator)
		# the optional parameters specifying the location (i.e. where in the world the simulation is of
		# and the compute node (such as NUS_HPC or LOCAL_MACBOOK)
		self.sim_location = None
		self.sim_compute_node = None
		self.speciation_rates = []
		# parameters for the application of speciation rates
		self.is_setup_speciation = False
		self.speciation_file = ""
		self.record_spatial = False
		self.record_fragments = False
		self.speciation_time_config_file = ""
		self.speciation_sample_file = ""
		self.speciation_rates_post_sim = []
		self.is_full = True
		self.pristine_fine_list = []
		self.pristine_coarse_list = []
		self.times_list = []  # this is the times for the maps to change (in generations)
		self.rates_list = []
		self.sample_time_list = []  # this is the list of temporal sampling points (in generations)

	def add_pristine_map(self, fine_map, coarse_map, time, rate):
		"""
		Adds an extra map to the list of pristine maps.

		:param fine_map: the pristine fine map file to add
		:param coarse_map: the pristine coarse map file to add
		:param time: the time to add (when the map is accurate)
		:param rate: the rate to add (the rate of forest change at this time)
		"""
		self.pristine_fine_list.append(fine_map)
		self.pristine_coarse_list.append(coarse_map)
		self.times_list.append(time)
		self.rates_list.append(rate)

	def add_sample_time(self, time):
		"""
		Adds an extra sample time to the list of times.

		This allows for multiple temporal sample points from within the same simulation.

		:param time: the sample time to add
		"""
		self.sample_time_list.append(time)

	def create_temporal_sampling_config(self, config_file):
		if len(self.sample_time_list) is not 0:
			config = ConfigParser.ConfigParser()
			config.add_section("main")
			for i, j in enumerate(self.sample_time_list):
				config.set("main", "time" + str(i), str(j))
			with open(config_file, "w") as conf:
				config.write(conf)
			self.time_config_file = config_file

	def create_map_config(self, output_file):
		"""
		Generates the map config file from reading the spatial structure of each of the provided files.

		:param str output_file: the file to output configuration data to (the map config file)


		"""
		if not config_success:
			raise ImportError("ConfigParser import was unsuccessful: cannot create config file.")
		if self.is_setup_map:
			config = ConfigParser.ConfigParser()
			config.add_section("sample_grid")
			config.set("sample_grid", "path", self.sample_map.file_name)
			x, y = map(str, self.sample_map.get_x_y())
			config.set("sample_grid", "x", x)
			config.set("sample_grid", "y", y)
			if self.sample_map.file_name is None:
				config.set("sample_grid", "mask", "null")
			else:
				config.set("sample_grid", "mask", self.sample_map.file_name)
			config.add_section("fine_map")
			config.set("fine_map", "path", self.fine_map.file_name)
			x, y = map(str, self.fine_map.get_x_y())
			config.set("fine_map", "x", str(x))
			config.set("fine_map", "y", str(y))
			config.set("fine_map", "x_off", str(self.fine_map.x_offset))
			config.set("fine_map", "y_off", str(self.fine_map.y_offset))
			config.add_section("coarse_map")
			if self.coarse_map.file_name is not None:
				config.set("coarse_map", "path", self.coarse_map.file_name)
				x, y = map(str, self.coarse_map.get_x_y())
				config.set("coarse_map", "x", str(x))
				config.set("coarse_map", "y", str(y))
				config.set("coarse_map", "x_off", str(self.coarse_map.x_offset))
				config.set("coarse_map", "y_off", str(self.coarse_map.y_offset))
				config.set("coarse_map", "scale", str(self.coarse_scale))
			else:
				config.set("coarse_map", "path", "null")
				config.set("coarse_map", "x", 0)
				config.set("coarse_map", "y", 0)
				config.set("coarse_map", "x_off", 0)
				config.set("coarse_map", "y_off", 0)
				config.set("coarse_map", "scale", 1)
			if len(self.pristine_coarse_list) is not 0 and len(self.pristine_fine_list) is not 0:
				for i, t in enumerate(self.times_list):
					try:
						tmp_fine = "pristine_fine" + str(i)
						config.add_section(tmp_fine)
						config.set(tmp_fine, "path", self.pristine_fine_list[i])
						config.set(tmp_fine, "number", str(i))
						config.set(tmp_fine, "time", str(t))
						config.set(tmp_fine, "rate", str(self.rates_list[i]))
						tmp_coarse = "pristine_coarse" + str(i)
						config.add_section(tmp_coarse)
						config.set(tmp_coarse, "path", self.pristine_coarse_list[i])
						config.set(tmp_coarse, "number", str(i))
						config.set(tmp_coarse, "time", str(t))
						config.set(tmp_coarse, "rate", str(self.rates_list[i]))
					except IndexError as ie:
						warnings.warn('Discrepancy between pristine file list, time list or rate list. Check inputs: ' +
									  ie.message)
						break
			with open(output_file, "w") as f:
				config.write(f)
			self.map_config = output_file
		else:
			raise RuntimeError("Cannot generate map config file without setting up map variables")

	def setup(self, coalescence_simulator=os.path.join(mod_directory, "build/default/./NECSim")):
		"""
		Set the location of the coalescence and speciation executables. Make sure that both programs have been compiled
		for the operating system running the simulations.

		:param str coalescence_simulator: the path to the Coal_v1 executable
		:return: None
		"""
		if coalescence_simulator is not None:
			self.coalescence_simulator = coalescence_simulator
			if not os.path.exists(coalescence_simulator):
				err = "File not found: " + str(coalescence_simulator)
				raise IOError(err)
		if coalescence_simulator is not None:
			self.is_setup = True

	def run_simple(self, seed, task, output, alpha, sigma, size):
		"""
		Runs a simple coalescence simulation on a square infinite landscape with the provided parameters.
		This requires a separate compilation of the inf_land version of the coalescence simulator.

		Note that this function returns richness=0 for failure to read from the file. It is assumed that there will
		be at least one species in the simulation.

		:param seed: the simulation seed
		:param task: the task (for file naming)
		:param output: the output directory
		:param alpha: the speciation rate (also nu)
		:param sigma: the normal distribution sigma value for dispersal
		:param size: the size of the world (so there will be size^2 individuals simulated)
		:return: the species richness in the simulation
		"""
		# TODO remove this function or modify for new NECSim argument structure
		self.call_list = [self.coalescence_simulator, seed, task, output, alpha, sigma, size]
		self.call_list = [str(x) for x in self.call_list]
		execute_log_info(self.call_list)
		# Now read the species richness from the database
		if not sqlite_import:
			warnings.warn("sqlite3 module not successfully imported. Cannot obtain richness.")
			return 0
		else:
			db = os.path.join(output, "SQL_data/data_" + str(task) + "_" + str(seed) + ".db")
			try:
				conn = sqlite3.connect(db)
			except sqlite3.OperationalError as oe:
				warnings.warn("Could not connect to database: " + db)
				raise (sqlite3.OperationalError(oe.message))
			try:
				c = conn.cursor().execute("SELECT COUNT(no_individuals) "
										  "FROM SPECIES_ABUNDANCES WHERE no_individuals > 0").fetchone()
				return c[0]
			except sqlite3.OperationalError as oe:
				warnings.warn(oe.message)
				warnings.warn("Could not find SPECIES_ABUNDANCES table in database " + db)
				return 0
			except Exception as e:
				warnings.warn(e.message)
				return 0

	def get_richness(self, speciation_rate=None, time=None):
		"""
		Calls coal_analyse.get_richness() with the supplied variables.

		Requires successful import of coal_analyse and sqlite3.

		:param speciation_rate: the speciation rate to extract system richness from.
		:param time: the time to extract system richness from
		:return: the species richness.
		"""
		if not sqlite_import:
			raise ImportError("sqlite3 module required for obtaining richness from database files.")
		else:
			db = os.path.join(self.output_directory,
							  "SQL_data/data_" + str(self.job_type) + "_" + str(self.job_num) + ".db")
			t = ca.Tree()
			t.set_database(db)
			return t.get_richness(speciation_rate=speciation_rate, time=time)

	def load_config(self, config_file):
		"""
		Loads the config file by reading the lines in order.

		:param str config_file: the config file to read in.
		"""
		# New method using ConfigParser
		if not config_success:
			raise ImportError("Failure to import ConfigParser: cannot load config file")
		else:
			config = ConfigParser.ConfigParser()
			config.read(config_file)
			self.job_num = config.getint("main", "job_num")
			self.job_type = config.getint("main", "job_type")
			self.map_config = config.get("main", "map_config")
			self.output_directory = config.get("main", "output_directory")
			self.min_speciation_rate = config.getfloat("main", "min_spec_rate")
			self.zfat = config.getfloat("main", "zfat")
			self.dispersal = config.getfloat("main", "lval")
			self.deme = config.getint("main", "deme")
			self.sample_size = config.getfloat("main", "sample_size")
			self.max_time = config.getint("main", "max_time")
			self.lambda_value = config.getfloat("main", "lambda")
			self.time_config_file = config.get("main", "time_config")
			self.min_num_species = config.getint("main", "min_species")
			self.full_config_file = config_file
			if config.has_section("spec_rate"):
				opts = config.options("spec_rate")
				for each in opts:
					self.speciation_rates.append(config.getfloat("spec_rate", each))
				# try:
				# 	f = open(config_file,'r')
				# except Exception as e:
				# 	print(e.message)
				# 	warnings.warn('Could not open' + config_file + '. Check directory is accessible.')
				# else:
				# 	self.job_num = f.readline().replace(" ","").replace("\n","").split("=")[-1]
				# 	self.job_type = f.readline().replace(" ","").replace("\n","").split("=")[-1]
				# 	self.map_config = f.readline().replace(" ","").replace("\n","").split("=")[-1]
				# 	self.output_directory = f.readline().replace(" ","").replace("\n","").split("=")[-1]
				# 	self.min_speciation_rate = f.readline().replace(" ","").replace("\n","").split("=")[-1]
				# 	self.zfat = f.readline().replace(" ","").replace("\n","").split("=")[-1]
				# 	self.lambda_value = f.readline().replace(" ","").replace("\n","").split("=")[-1]
				# 	self.deme = f.readline().replace(" ","").replace("\n","").split("=")[-1]
				# 	self.sample_size = f.readline().replace(" ","").replace("\n","").split("=")[-1]
				# 	self.max_time = f.readline().replace(" ","").replace("\n","").split("=")[-1]
				# 	self.lambda_value = f.readline().replace(" ","").replace("\n","").split("=")[-1]
				# 	self.time_config_file = f.readline().replace(" ","").replace("\n","").split("=")[-1]
				# 	self.min_num_species = f.readline().replace(" ","").replace("\n","").split("=")[-1]
				# 	for l in f.readlines():
				# 		self.speciation_rates.append(l.replace(" ","").replace("\n","").split("=")[-1])
				# 	f.close()
				# 	self.full_config_file = config_file

	def create_config(self, output_file):
		"""
		Generates the output config files. This version creates the concise version of the config file.

		:param str output_file: the file to generate the config option. Must be a path to a .txt file.
		"""
		if not config_success:
			raise ImportError("ConfigParser import was unsuccessful: cannot create config file.")
		if self.is_setup_map and self.is_setup_param and self.is_setup:
			# New method using ConfigParser
			config = ConfigParser.ConfigParser()
			config.add_section("main")
			config.set("main", "job_num", str(self.job_num))
			config.set("main", "job_type", str(self.job_type))
			if self.map_config is None or self.map_config is "":
				raise RuntimeError("Cannot create config without map configuration options set.")
			else:
				config.set("main", "map_config", self.map_config)
			config.set("main", "output_directory", self.output_directory)
			config.set("main", "min_spec_rate", str(self.min_speciation_rate))
			config.set("main", "zfat", str(self.zfat))
			config.set("main", "lval", str(self.dispersal))
			config.set("main", "deme", str(self.deme))
			config.set("main", "sample_size", str(self.sample_size))
			config.set("main", "max_time", str(self.max_time))
			config.set("main", "lambda", str(self.lambda_value))
			config.set("main", "time_config", self.time_config_file)
			config.set("main", "min_species", str(self.min_num_species))
			if len(self.speciation_rates) == 0:
				config.add_section("spec_rates")
				for i, j in enumerate(self.speciation_rates):
					spec_rate = "spec_" + str(i)
					config.set("spec_rates", spec_rate, j)
			with open(output_file, "w") as config_file:
				config.write(config_file)
			self.full_config_file = output_file
		else:
			raise RuntimeError("Setup has not been completed, cannot create config file")

	def set_map_config(self, file):
		"""
		Sets a specific map config and tells the program that full commmand-line parsing is not required.

		:param str file: the file to read map config options from
		"""
		self.map_config = file
		self.is_full = False

	def set_map_files(self, sample_file, fine_file=None, coarse_file=None, pristine_fine_file=None,
					  pristine_coarse_file=None):
		"""
		Sets the map files (or to null, if none specified). It then calls detect_map_dimensions() to correctly read in
		the specified dimensions.
		Note that if sample_file is "null", values will remain at 0.
		If coarse_file is "null", it will default to the size of fine_file with zero offset.

		:param sample_file: the sample map file. Provide "null" if on samplemask is required.
		:param fine_file: the fine map file. Defaults to "null" if none provided.
		:param coarse_file: the coarse map file. Defaults to "null" if none provided.
		:param pristine_fine_file: the pristine fine map file. Defaults to "null" if none provided.
		:param pristine_coarse_file: the pristine coarse map file. Defaults to "null" if none provided.

		:rtype None

		:return None
		"""
		if fine_file is None:
			fine_file = "null"
		if coarse_file is None:
			coarse_file = "null"
		if pristine_fine_file is None:
			pristine_fine_file = "null"
		if pristine_coarse_file is None:
			pristine_coarse_file = "null"
		self.set_map_parameters(sample_file, 0, 0, fine_file, 0, 0, 0, 0, coarse_file, 0, 0, 0, 0, 0,
								pristine_fine_file, pristine_coarse_file)

	def detect_map_dimensions(self):
		"""
		Detects all the map dimensions for the provided files (where possible) and sets the respective values.
		This is intended to be run after set_map_files()
		:return: None
		"""
		self.fine_map.set_dimensions()
		if self.sample_map.file_name is "null":
			self.sample_map.set_dimensions(x_size=self.fine_map.x_size, y_size=self.fine_map.y_size,
										   x_offset=self.fine_map.x_offset, y_offset=self.fine_map.y_offset)
		else:
			self.sample_map.set_dimensions()
		self.fine_map.x_offset = -self.fine_map.calculate_offset(self.sample_map)[0]
		self.fine_map.y_offset = -self.fine_map.calculate_offset(self.sample_map)[1]
		if self.coarse_map.file_name is "null":
			self.coarse_map = copy.deepcopy(self.fine_map)
			self.coarse_scale = 1
			self.coarse_map.file_name = "null"
			self.coarse_map.x_offset = 0
			self.coarse_map.y_offset = 0
		else:
			self.coarse_map.set_dimensions()
			self.coarse_map.x_offset = -self.coarse_map.calculate_offset(self.fine_map)[0]
			self.coarse_map.y_offset = -self.coarse_map.calculate_offset(self.fine_map)[1]
			self.coarse_scale = self.fine_map.calculate_scale(self.coarse_map)

	def set_map_parameters(self, sample_file, sample_x, sample_y, fine_file, fine_x, fine_y, fine_x_offset,
						   fine_y_offset, coarse_file, coarse_x, coarse_y,
						   coarse_x_offset, coarse_y_offset, coarse_scale, pristine_fine_map, pristine_coarse_map):
		"""

		Set up the map objects with the required parameters. This is required for csv file usage.

		Note that this function is not recommended for tif file usage, as it is much simpler to call set_map_files() and
		which should automatically calculate map offsets, scaling and dimensions.

		:param sample_file: the sample file to use, which should contain a boolean mask of where to sample
		:param sample_x: the x dimension of the sample file
		:param sample_y: the y dimension of the sample file
		:param fine_file: the fine map file to use (must be equal to or larger than the sample file)
		:param fine_x: the x dimension of the fine map file
		:param fine_y: the y dimension of the fine map file
		:param fine_x_offset: the x offset of the fine map file
		:param fine_y_offset: the y offset of the fine map file
		:param coarse_file: the coarse map file to use (must be equal to or larger than fine map file)
		:param coarse_x: the x dimension of the coarse map file
		:param coarse_y: the y dimension of the coarse map file
		:param coarse_x_offset: the x offset of the coarse map file at the resolution of the fine map
		:param coarse_y_offset: the y offset of the coarse map file at the resoultion of the fine map
		:param coarse_scale: the relative scale of the coarse map compared to the fine map (must match x and y scaling)
		:param pristine_fine_map: the pristine fine map file to use (must have dimensions equal to fine map)
		:param pristine_coarse_map: the pristine coarse map file to use (must have dimensions equal to coarse map)
		"""
		if not self.is_setup_map:
			self.sample_map.set_dimensions(sample_file, sample_x, sample_y)
			self.fine_map.set_dimensions(fine_file, fine_x, fine_y, fine_x_offset, fine_y_offset)
			self.coarse_map.set_dimensions(coarse_file, coarse_x, coarse_y, coarse_x_offset, coarse_y_offset)
			self.coarse_scale = coarse_scale
			self.pristine_fine_map_file = pristine_fine_map
			self.pristine_coarse_map_file = pristine_coarse_map
			self.is_setup_map = True
		else:
			err = "Map objects are already set up."
			warnings.warn(err, RuntimeWarning)

	def set_simulation_params(self, job_num, job_type, output_directory, min_speciation_rate, zfat, dispersal, deme,
							  sample_size, max_time,
							  lambda_value, min_num_species, forest_change_param = 0.0, pristine_forest = 1,
							  time_config_file = "null"):
		"""
		Set all the simulation parameters apart from the map objects.

		:param int job_num: the unique job number for this simulation set
		:param int job_type: the job type (used for easy file identification after simulations are complete)
		:param str output_directory: the output directory to store the SQL database
		:param float min_speciation_rate: the minimum speciation rate to simulate
		:param float zfat: the dispersal zfat value, also called eta.
		:param float dispersal: the dispersal L value.
		:param int deme: the deme size (in individuals per cell)
		:param float sample_size: the sample size of the deme (decimal 0-1)
		:param float max_time: the maximum allowed simulation time (in seconds)
		:param float lambda_value: the relative cost of travelling through non-habitat (default is 1)
		:param int min_num_species: the minimum number of species known to exist
		:param float forest_change_param: the rate of forest change over time
		:param float pristine_forest: the time in generations since a pristine state was achieved
		:param str time_config_file: the path to the time config file (or null)
		"""
		if not self.is_setup_param:
			self.job_num = job_num
			self.output_directory = output_directory
			self.job_type = job_type
			self.min_speciation_rate = min_speciation_rate
			self.zfat = zfat
			self.dispersal = dispersal
			self.deme = deme
			self.sample_size = sample_size
			self.max_time = max_time
			self.lambda_value = lambda_value
			self.min_num_species = min_num_species
			self.forest_change_param = forest_change_param
			self.pristine_forest = pristine_forest
			self.time_config_file = time_config_file
			self.is_setup_param = True
		else:
			err = "Parameters already set up."
			warnings.warn(err, RuntimeWarning)

	def check_simulation_params(self):
		"""
		Checks that simulation parameters have been correctly set and the program is ready for running.
		Note that these checks have not been fully tested and are probably uneccessary in a large number of cases.
		"""
		if not self.is_setup_param:
			print(self.output_directory)
			if self.output_directory == "" or self.output_directory is None or self.output_directory is 'null':
				raise RuntimeError('Output directory not set.')
			else:
				self.is_setup_param = True
		if not self.is_setup:
			raise RuntimeError('Coalescence and Speciation programs not identified')

	def resume_sim(self, directory, job_num, job_type, max_time):
		"""
		Resumes the simulation from the specified directory, looking for the simulation with the specified seed and task
		referencing.

		:param directory: the directory to search for the paused simulation
		:param job_num: the seed of the paused simulation
		:param job_type: the task of the paused simulation
		:param max_time: the maximum time to run simulations for

		.. note: A max time of 0 uses the previous simulation maximum time.
		:return: None
		"""
		self.output_directory = directory
		self.job_num = job_num
		self.job_type = job_type
		self.max_time = max_time
		if self.is_setup:
			call_list = [self.coalescence_simulator, "-r", directory, job_num, job_type, max_time]
			try:
				execute_log_info([str(x) for x in call_list])
			except (OSError, subprocess.CalledProcessError) as err:
				err.message = "Error thrown while trying to resume simulation: " + err.message
				raise err
		else:
			raise RuntimeError("Setup is incomplete. Please run setup() first.")

	def complete_setup(self):
		"""Completes the setup process by creating the list that will be passed to the c++ executable"""
		if (self.is_setup_map or self.is_full) and self.is_setup_param and self.is_setup:
			if self.is_setup_complete:
				err = "Set up already completed"
				warnings.warn(err, RuntimeWarning)
			else:
				if not self.is_full:
					tmp_call_list = [self.coalescence_simulator, self.job_num, self.job_type, self.map_config,
									 self.output_directory, self.min_speciation_rate, self.zfat, self.dispersal,
									 self.deme, self.sample_size, self.max_time, self.lambda_value,
									 self.time_config_file,
									 self.min_num_species]
				# print(tmp_call_list)
				else:
					tmp_call_list = [self.coalescence_simulator, "-f", self.job_num, self.sample_map.x_size,
									 self.sample_map.y_size,
									 self.fine_map.file_name,
									 self.fine_map.x_size, self.fine_map.y_size, self.fine_map.x_offset,
									 self.fine_map.y_offset,
									 self.coarse_map.file_name, self.coarse_map.x_size, self.coarse_map.y_size,
									 self.coarse_map.x_offset,
									 self.coarse_map.y_offset, self.coarse_scale,
									 self.output_directory, self.min_speciation_rate, self.zfat, self.deme,
									 self.sample_size,
									 self.max_time,
									 self.lambda_value, self.job_type, self.min_num_species,
									 self.pristine_fine_map_file,
									 self.pristine_coarse_map_file,
									 self.forest_change_param, self.pristine_forest, self.dispersal,
									 self.sample_map.file_name,
									 self.time_config_file]
				# print(tmp_call_list)
				# Make sure that there is no empty list appended if there are no speciation rates supplied.
				if len(self.speciation_rates) is not 0:
					tmp_call_list.extend(self.speciation_rates)
				self.call_list = [str(x) for x in tmp_call_list]
			# print self.call_list
			self.is_setup_complete = True
		else:
			err = "Set up is incomplete: Map/Full: " + str(self.is_setup_map or self.is_full) + " Param: "
			err += str(self.is_setup_param) + " Setup: " + str(self.is_setup)
			raise RuntimeError(err)

	def set_speciation_rates(self, speciation_rates):
		"""Add speciation rates for analysis at the end of the simulation. This is optional

		:param list speciation_rates: a list of speciation rates to apply at the end of the simulation
		"""
		self.speciation_rates = [str(x) for x in speciation_rates]

	def run_checks(self):
		"""Check that the simulation is correctly set up and that all the required files exist."""
		if not self.is_setup_complete and self.is_setup and self.is_setup_map and self.is_setup_param:
			err = "Set up is incomplete."
			raise RuntimeError(err)
		else:
			for each in [self.coarse_map, self.fine_map, self.sample_map]:
				each.check_map()
			# print("Checks run successfully")

	def run_coalescence(self):
		"""Attempt to run the simulation with the given simulation set-up.
		This is the main routine performing the actual simulation which will take a considerable amount of time."""
		if self.is_setup_complete:
			# Make the output directory if it doesn't yet exist
			if not os.path.exists(self.output_directory):
				os.makedirs(self.output_directory)
			# Call the c++ code and run the simulation
			execute_log_info(self.call_list)
		else:
			err = "Set up is incomplete."
			raise RuntimeError(err)



