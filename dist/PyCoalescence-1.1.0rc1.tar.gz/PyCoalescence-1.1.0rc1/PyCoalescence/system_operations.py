"""
Contains the general purpose operations that will be used by multiple modules, including calling subprocess properly,
logging methods and file management.

The functions are contained here as they are required by many different modules. Note that logging will not raise an
exception if there has been no call to set_logging_method()

"""

import subprocess
import logging
import sys
import os

# Logging will not raise an exception if there has been no logging file set.
logging.raiseExceptions = True
# Set up the module directory
mod_directory = os.path.dirname(os.path.abspath(__file__))


def execute(cmd, **kwargs):
	"""
	Calls the command using subprocess and yields the running output for printing to terminal. Any errors produced by
	subprocess call will be redirected to logging.warning() after the subprocess call is complete.

	:param cmd: the command to execute using subprocess.Popen()
	:return a line from the execution output
	"""
	# print(cmd)
	# print(kwargs)
	popen = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True, **kwargs)
	for stdout_line in iter(popen.stdout.readline, ""):
		yield stdout_line
	for stderr_line in iter(popen.stderr.readline, ""):
		logging.warning(stderr_line)
	popen.stdout.close()
	popen.stderr.close()
	return_code = popen.wait()
	if return_code:
		raise subprocess.CalledProcessError(return_code, cmd)


def execute_log_info(cmd, **kwargs):
	"""
	Calls execute() with the supplied command and keyword arguments, and redirects stdout to the logging object.

	:param cmd: the command to execute using subprocess.Popen()
	:param kwargs: keyword arguments to be passed to subprocess.Popen()
	:return: None
	"""
	for line in execute(cmd, **kwargs):
		logging.info(line.strip("\n"))
	execute(cmd, **kwargs)


def set_logging_method(logging_level=logging.INFO, output=None, **kwargs):
	"""
	Initiates the logging process.

	:param logging_level: the detail in logging output: can be one
	 				     of logging.INFO (default), logging.WARNING, logging.DEBUG, logging.ERROR or logging.CRITICAL
	:param output: the output logfile (or None to redirect to terminal via stdout)
	:param kwargs: additional arguments to pass to the logging.basicConfig() call

	:return: None
	"""
	if output is None:
		logging.basicConfig(stream=sys.stdout, format='%(levelname)s:%(message)s', level=logging_level, **kwargs)
	else:
		logging.basicConfig(filename=output, format='%(levelname)s:%(message)s', level=logging_level, **kwargs)
	logging.captureWarnings(True)
