"""
Sets up the NECSim executables. It configures the install by detecting system components and compiles the ``c++`` files,
if possible. Command line flags can be provided (see :ref:`Compilation Options <sec Compilation Options>` for more
information) to modify the install.
"""

from __future__ import print_function  # Only Python 2.x
import sys
import subprocess
import os
import warnings
import logging

# Import system operations for subprocess executation and log file handling

from system_operations import execute, set_logging_method, mod_directory



def do_compile():
	"""
	Compiles the c++ NECSim program by running make. This changes the working directory to wherever the module has been
	installed for the subprocess call.
	"""
	# Check that the make file exists
	if os.path.exists(os.path.join(mod_directory, "NECSim/")):
		try:
			for path in execute(["make"], cwd=os.path.join(mod_directory, "NECSim/")):
				logging.info(path.strip("\n"))
		except subprocess.CalledProcessError as cpe:
			warnings.warn(cpe.message)
			warnings.warn("Compilation attempted, but error thrown.")
	else:
		raise IOError("NECSim module does not exist! Check relative file path")


def move_executable(directory=os.path.join(mod_directory, "build/default/")):
	"""
	Moves the executable to the specified directory from within NECSim. Will always look for NECSim relative to the
	setup.py (so can be called from another module location).
	This allows for multiple compilation options with different versions stored in different folders.

	Throws an IOError when the NECSim executable is not found.

	:param directory: the directory to move the NECSim excecutable to.
	"""
	# Get absolute paths so that NECSim location is correct, and directory to move to can be supplied in relative format
	# from the parent file working directory.
	source_file = os.path.join(mod_directory, "NECSim/NECSim")
	source_file2 = os.path.join(mod_directory, "NECSim/SpeciationCounter")
	if not os.path.exists(source_file):
		raise IOError("Could not find " + source_file + ". Check program has been successfully compiled")
	if not os.path.exists(source_file2):
		raise IOError("Could not find " + source_file2 + ". Check program has been successfully compiled")
	if not os.path.exists(directory):
		dirname = os.path.dirname(directory)
		try:
			os.makedirs(dirname)
		except OSError:
			try:
				os.mkdir(dirname)
			except OSError as ose:
				warnings.warn("Could not create directory " + directory)
				raise ose
	os.rename(source_file, os.path.join(directory, "NECSim"))
	os.rename(source_file2, os.path.join(directory, "SpeciationCounter"))


def configure(opts=None):
	"""
	Runs ./configure --opts with the supplied options. This should create the makefile for compilation, otherwise a
	RuntimeError will be thrown.

	:param opts: a list of options to pass to the ./configure call
	"""
	if os.path.exists(os.path.join(mod_directory, "NECSim/configure")):
		try:
			if opts is None:
				for path in execute(["./configure", "--with-verbose", "--with-fat_tail_dispersal"],
									cwd=os.path.join(mod_directory, "NECSim/")):
					logging.info(path.strip("\n"))
			else:
				command = ["./configure"]
				command.extend(opts)
				for path in execute(command, cwd=os.path.join(mod_directory, "NECSim/")):
					logging.info(path.strip("\n"))
		except subprocess.CalledProcessError as cpe:
			cpe.message += "Configuration attempted, but error thrown"
			raise cpe
	else:
		raise RuntimeError("File NECSim/configure does not exist. Check installation has been successful.")


def autoconf():
	"""
	Runs the `autoconf` bash function (assuming that autoconf is available) to create the `configure` executable.
	"""
	try:
		for path in execute(["make"], cwd=os.path.join(mod_directory, "NECSim/")):
			logging.info(path.strip("\n"))
	except subprocess.CalledProcessError as cpe:
		warnings.warn("Could not run autoconf function to generate configure executable. "
					  "Please run this functionality manually if installation fails.")
		warnings.warn(cpe.message)


def clean():
	"""
	Runs make clean in the NECSim directory to wipe any previous potential compile attempts.
	"""
	try:
		for path in execute(["make", "clean"], cwd=os.path.join(mod_directory, "NECSim/")):
			logging.info(path.strip("\n"))
	except subprocess.CalledProcessError as cpe:
		warnings.warn(cpe.message)
		raise RuntimeError("Make file has not been generated. Cannot clean.")


def main(argv=[None], logging_level=logging.INFO):
	"""
	Runs the install for compile options provided via the command line, or with default options if no options exist.
	Running with ``-help`` or `-h` will display the compilation configurations called from ``./configure``.
	"""
	set_logging_method(logging_level=logging_level)
	if len(argv) == 1:
		warnings.warn("No compile options provided, using defaults.")
		autoconf()
		configure()
		clean()
		do_compile()
		move_executable()
	else:
		if argv[1] == "--h" or argv[1] == "-h" or argv[1] == "-help" or argv[1] == "--help":
			for path in execute(["./configure", "--help"], cwd=os.path.join(mod_directory, "NECSim/")):
				print(path, end="")
			exit(0)
		autoconf()
		configure(argv[1:])
		clean()
		do_compile()
		move_executable()


if __name__ == "__main__":
	main(sys.argv)
