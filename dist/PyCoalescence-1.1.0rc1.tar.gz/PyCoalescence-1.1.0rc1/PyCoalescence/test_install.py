"""
Compiles NECSim for several simulation scenarios and tests the output to make sure simulation results are as expected.
Also performs limited tests of the PyCoalescence setup routines.

.. note:: If test_install.py has not been run before, compilation may take a while, depending on your system, as it
   compiles NECSim for several different options.
"""
from __future__ import absolute_import

import unittest
from shutil import rmtree
import warnings

try:
	import sqlite3
except ImportError:
	import sqlite as sqlite3

from coalescence import Coalescence, Map
from coal_analyse import Tree
from setup import *
from system_operations import *
from setup import main as setupmain

def make_all_compile(recompile=False, build_dir="build/", opt_list=None, folder_list=None):
	"""
	Compiles the program for a set number of options arguments. The default behaviour (override by recompile=True) is to
	only compile if there is no NECSim or SpeciationCounter executable.

	Without providing an build_dir, opt_list or folder_list, it takes the following values:
	build_dir = "build/nv/"
	opt_list = [["--with-normal_dispersal", "--with-infinite_landscape"],
				[ "--with-fat_tail_dispersal"],["--with-normal_dispersal"]]

	folder_list = ["norm_inf_land/", "fat_tailed/", "norm/"]

	These are the required executables for performing the unit testing of PyCoalescence.

	:param recompile: if True, deletes any existing file and recompiles.
	:param build_dir: optionally set a build directory. Defaults to the non-verbose version, saving outputs in build/nv/
	:param opt_list: optionally set a list of options to compile with. Must also specify a folder_list
	:param folder_list: optionally set a list of output folders. Must also specify an opt_list
	"""
	set_logging_method(logging_level=logging.WARNING, output=None)
	if (opt_list is None and folder_list is not None) or (folder_list is None and opt_list is not None):
		raise RuntimeError("Attempt to set option list without specifying a folder list.")
	if opt_list is None:
		opt_list = [["--with-normal_dispersal", "--with-infinite_landscape"],
		            ["--with-fat_tail_dispersal", "--with-infinite_landscape"], ["--with-normal_dispersal"],
		            ["--with-verbose", "--with-normal-dispersal"]]
		folder_list = ["nv/norm_inf_land/", "nv/fat_tailed/", "nv/norm/", "v/norm/"]
	autoconf()
	for i, each in enumerate(opt_list):
		try:
			output_path = os.path.join(build_dir, folder_list[i])
			if recompile or not os.path.exists(os.path.join(output_path, "NECSim")) or not \
					os.path.exists(os.path.join(output_path, "SpeciationCounter")):
				configure(each)
				clean()
				do_compile()
				move_executable(output_path)
		except RuntimeError as rte:
			warnings.warn(rte.message)
		except IOError as ioe:
			warnings.warn(ioe.message)
		except Exception as ue:
			raise ue


def setUpModule():
	"""
	Copies the log folder to a new folder so that the normal log folder can be removed entirely.
	"""
	if not os.path.exists("build/default/NECSim") or not os.path.exists("build/default/SpeciationCounter"):
		setupmain(logging_level=logging.WARNING)
	make_all_compile()
	if not os.path.exists("output"):
		os.mkdir("output")
	global log_path
	log_path = None
	if os.path.exists("Logs"):
		try:
			log_path = "Logs2"
			os.rename("Logs/", "Logs2")
		except OSError:
			try:
				log_path = "Logs_tmp"
				os.rename("Logs/", "Logs_tmp")
			except OSError as oe:
				warnings.warn(oe.message)
				warnings.warn("Cannot rename Log directory: deleting instead.")
				log_path = None


def tearDownModule():
	"""
	Overrides the in-built behaviour for tearing down the file. Removes the output folder to clean up after testing.
	"""
	# pass
	rmtree("output", True)
	rmtree("Logs", True)
	if log_path is not None:
		os.rename(log_path, "Logs")


def test_install():
	"""
	Tests the install for certain parameters to ensure that output is as expected.
	"""
	# testSuite2 = unittest.TestLoader().loadTestsFromTestCase(CoalComplexRun)
	# unittest.TextTestRunner().run(testSuite2)
	unittest.makeSuite(MapTest)
	unittest.makeSuite(CoalNorm)
	unittest.makeSuite(CoalInfLand)
	unittest.makeSuite(CoalFatInf)
	unittest.makeSuite(CoalAnalyseTest)
	unittest.makeSuite(CoalTifTest)
	unittest.makeSuite(CoalTifTestCoarse)
	unittest.makeSuite(CoalConfigReadWrite)
	unittest.makeSuite(CoalComplexRun)
	unittest.makeSuite(CoalComplexRun2)
	unittest.makeSuite(CoalSampleRun)
	unittest.makeSuite(CoalPauseTest)
	unittest.makeSuite(CoalFuncCheck)
	unittest.main()


class MapTest(unittest.TestCase):
	"""
	Tests the functions for the Map object work properly.
	"""

	@classmethod
	def setUpClass(self):
		"""
		Sets up the Map object
		"""
		self.fine_map = Map()
		self.fine_map.file_name = "sample/SA_sample_fine.tif"
		self.coarse_map = Map()
		self.coarse_map.file_name = "sample/SA_sample_coarse.tif"

	def testDetectGeoTransform(self):
		"""
		Tests the fine and coarse map geo transforms
		"""
		# Test the fine map
		x, y, ulx, uly, xres, yres = self.fine_map.get_dimensions()
		self.assertEqual(x, 13)
		self.assertEqual(y, 13)
		self.assertAlmostEqual(ulx, -78.375, 8)
		self.assertAlmostEqual(uly, 0.8583333333333, 8)
		self.assertAlmostEqual(xres, 0.00833333333333, 8)
		self.assertAlmostEqual(yres, -0.0083333333333333, 8)
		# Now test the coarse map
		x, y, ulx, uly, xres, yres = self.coarse_map.get_dimensions()
		self.assertEqual(x, 35)
		self.assertEqual(y, 41)
		self.assertAlmostEqual(ulx, -78.466666666, 8)
		self.assertAlmostEqual(uly, 0.975, 8)
		self.assertAlmostEqual(xres, 0.00833333333333, 8)
		self.assertAlmostEqual(yres, -0.0083333333333333, 8)

	def testGetXY(self):
		"""
		Tests the get_x_y() functionality
		"""
		x, y = self.fine_map.get_x_y()
		self.assertEqual(x, 13)
		self.assertEqual(y, 13)
		x, y = self.coarse_map.get_x_y()
		self.assertEqual(x, 35)
		self.assertEqual(y, 41)

	def testSetDimensions(self):
		"""
		Tests set_dimensions method
		"""
		tmp = Map()
		tmp.set_dimensions("sample/SA_sample_fine.tif")
		x, y, ulx, uly, xres, yres = [tmp.x_size, tmp.y_size, tmp.x_offset, tmp.y_offset, tmp.x_res, tmp.y_res]
		self.assertEqual(x, 13)
		self.assertEqual(y, 13)
		self.assertAlmostEqual(ulx, -78.375, 8)
		self.assertAlmostEqual(uly, 0.8583333333333, 8)
		self.assertAlmostEqual(xres, 0.00833333333333, 8)
		self.assertAlmostEqual(yres, -0.0083333333333333, 8)

	def testFail(self):
		"""
		Tests the correct exceptions are thrown when stupid things are attempted!
		"""
		map_fail = Map()
		map_fail.file_name = "sample/not_here.tif"

		with self.assertRaises(IOError):
			map_fail.get_dimensions()
		map_fail.file_name = "sample/SA_sample_fine"
		with self.assertRaises(IOError):
			map_fail.get_dimensions()
		map_fail.file_name = None
		with self.assertRaises(RuntimeError):
			map_fail.set_dimensions()
		with self.assertRaises(RuntimeError):
			map_fail.check_map()

	def testOffset(self):
		"""
		Tests that the offsets are correctly calculated between the fine and coarse maps
		"""
		self.assertListEqual(self.coarse_map.calculate_offset(self.fine_map), [-11, -14])
		self.assertListEqual(self.coarse_map.calculate_offset(self.coarse_map), [0, 0])
		self.assertListEqual(self.fine_map.calculate_offset(self.coarse_map), [11, 14])


class CoalNorm(unittest.TestCase):
	"""
	Tests the main coalescence set up routine by running some tiny simulations and checking that simulation parameters
	are passed properly. This function requires there to be a NECSim executable in build/nv/norm and compiled
	with the correct defines. make_all_compile() should automatically generate these executables.
	"""

	@classmethod
	def setUpClass(self):
		"""
		Sets up the Coalescence object test case.
		"""
		self.coal = Coalescence()
		self.tree = Tree()
		self.coal.setup(coalescence_simulator="build/nv/norm/./NECSim")
		self.coal.set_simulation_params(0, 0, "output", 0.1, 4, 4, 1, 1.0, 2, 1, 1, 0, 2, "null")
		self.coal.set_map_parameters("null", 10, 10, "null", 10, 10, 0, 0, "null", 20, 20, 0, 0, 1, "null", "null")
		self.coal.set_speciation_rates([0.1, 0.2])
		self.coal.complete_setup()
		self.coal.run_checks()
		self.coal.run_coalescence()
		self.tree.set_database("output/SQL_data/data_0_0.db")
		self.tree.calculate_octaves()
		self.tree.calculate_richness()

	@classmethod
	def tearDownClass(cls):
		"""
		Removes the files from output."
		:return:
		"""
		pass  # rmtree("output",True)

	def test_sim_params_stored(self):
		"""
		Tests the full simulation setup, checking species richness is correct and species abundance calculations are
		correct.
		:return:
		"""
		params = list(self.tree.get_simulation_parameters())
		params_compare = [0, 0, 'output', 0.1, 4.0, 4.0, 1, 1.0, 2.0, 1.0, 1, 0.0, 2.0, 'null', 'null', 20, 20, 0, 0,
		                  1.0, 'null', 10, 10, 0, 0, 'null', 10, 10, 'null', 'null', 1]
		self.assertListEqual(params, params_compare)
		self.assertEqual(self.tree.get_job()[0], 0)
		self.assertEqual(self.tree.get_job()[1], 0)

	def test_richness(self):
		"""
		Tests that the richness stored in the SQL file is correct.
		Note that this is actually a test of both the c++ (NECSim) and the python front-end.
		"""
		self.assertEqual(self.tree.get_richness(speciation_rate=0.1), 34)
		self.assertEqual(self.tree.get_richness(speciation_rate=0.2), 45)

	def test_richness_landscape(self):
		"""
		Tests the landscape richness function which calculates landscape richness for each time and speciation rate.
		"""
		richness = self.tree.get_landscape_richness()
		richness_01 = [x[2] for x in richness if x[0] == 0.1][0]
		richness_02 = [x[2] for x in richness if x[0] == 0.2][0]
		self.assertEqual(richness_01, 34)
		self.assertEqual(richness_02, 45)


class CoalInfLand(unittest.TestCase):
	"""
	Performs a simulation on an infinite landscape with a normal dispersal kernel and checks outputs.
	"""

	@classmethod
	def setUpClass(self):
		"""
		Sets up the Coalescence object test case.
		"""
		self.coal = Coalescence()
		self.tree = Tree()
		self.coal.setup(coalescence_simulator="build/nv/norm_inf_land/./NECSim")
		self.coal.set_simulation_params(2, 2, "output", 0.1, 4, 4, 1, 1.0, 2, 1, 1, 0, 2, "null")
		self.coal.set_map_parameters("null", 10, 10, "null", 10, 10, 0, 0, "null", 20, 20, 0, 0, 1, "null", "null")
		self.coal.set_speciation_rates([0.1, 0.2])
		self.coal.complete_setup()
		self.coal.run_checks()
		self.coal.run_coalescence()
		self.tree.set_database("output/SQL_data/data_2_2.db")
		self.tree.calculate_octaves()
		self.tree.calculate_richness()

	def test_sim_params_stored(self):
		"""
		Tests the full simulation setup, checking species richness is correct and species abundance calculations are
		correct.
		:return:
		"""
		params = list(self.tree.get_simulation_parameters())
		params_compare = [2, 2, 'output', 0.1, 4.0, 4.0, 1, 1.0, 2.0, 1.0, 1, 0.0, 2.0, 'null', 'null', 20, 20, 0, 0,
		                  1.0, 'null', 10, 10, 0, 0, 'null', 10, 10, 'null', 'null', 1]
		self.assertListEqual(params, params_compare)
		self.assertEqual(self.tree.get_job()[0], 2)
		self.assertEqual(self.tree.get_job()[1], 2)

	def test_richness(self):
		"""
		Tests that the richness stored in the SQL file is correct.
		Note that this is actually a test of both the c++ (NECSim) and the python front-end.
		"""
		self.assertEqual(self.tree.get_richness(speciation_rate=0.1), 56)
		self.assertEqual(self.tree.get_richness(speciation_rate=0.2), 64)

	def test_richness_landscape(self):
		"""
		Tests the landscape richness function which calculates landscape richness for each time and speciation rate.
		"""
		richness = self.tree.get_landscape_richness()
		richness_01 = [x[2] for x in richness if x[0] == 0.1][0]
		richness_02 = [x[2] for x in richness if x[0] == 0.2][0]
		self.assertEqual(richness_01, 56)
		self.assertEqual(richness_02, 64)


class CoalFatInf(unittest.TestCase):
	"""
	Performs a basic simulation on an infinite landscape with a fat-tailed dispersal to checks outputs.
	"""

	@classmethod
	def setUpClass(self):
		"""
		Sets up the Coalescence object test case.
		"""
		self.coal = Coalescence()
		self.tree = Tree()
		self.coal.setup(coalescence_simulator="build/nv/fat_tailed/./NECSim")
		self.coal.set_simulation_params(1, 1, "output", 0.1, 4, 4, 1, 1.0, 2, 1, 1, 0, 2, "null")
		self.coal.set_map_parameters("null", 10, 10, "null", 10, 10, 0, 0, "null", 20, 20, 0, 0, 1, "null", "null")
		self.coal.set_speciation_rates([0.1, 0.2])
		self.coal.complete_setup()
		self.coal.run_checks()
		self.coal.run_coalescence()
		self.tree.set_database("output/SQL_data/data_1_1.db")
		self.tree.calculate_octaves()
		self.tree.calculate_richness()

	def test_sim_params_stored(self):
		"""
		Tests the full simulation setup, checking species richness is correct and species abundance calculations are
		correct.
		:return:
		"""
		params = list(self.tree.get_simulation_parameters())
		params_compare = [1, 1, 'output', 0.1, 4.0, 4.0, 1, 1.0, 2.0, 1.0, 1, 0.0, 2.0, 'null', 'null', 20, 20, 0, 0,
		                  1.0, 'null', 10, 10, 0, 0, 'null', 10, 10, 'null', 'null', 1]
		self.assertListEqual(params, params_compare)
		self.assertEqual(self.tree.get_job()[0], 1)
		self.assertEqual(self.tree.get_job()[1], 1)

	def test_richness(self):
		"""
		Tests that the richness stored in the SQL file is correct.
		Note that this is actually a test of both the c++ (NECSim) and the python front-end.
		"""
		self.assertEqual(self.tree.get_richness(speciation_rate=0.1), 73)
		self.assertEqual(self.tree.get_richness(speciation_rate=0.2), 78)

	def test_richness_landscape(self):
		"""
		Tests the landscape richness function which calculates landscape richness for each time and speciation rate.
		"""
		richness = self.tree.get_landscape_richness()
		richness_01 = [x[2] for x in richness if x[0] == 0.1][0]
		richness_02 = [x[2] for x in richness if x[0] == 0.2][0]
		self.assertEqual(richness_01, 73)
		self.assertEqual(richness_02, 78)


class CoalTifTest(unittest.TestCase):
	"""
	Tests the tif file reading ability and correct fine map parameter detection.
	This requires the file SA_sample.tif in sample/
	"""

	@classmethod
	def setUpClass(self):
		"""
		Sets up the Coalescence object test case.
		"""
		self.coal = Coalescence()
		self.tree = Tree()
		self.coal.setup(coalescence_simulator="build/nv/fat_tailed/./NECSim")
		self.coal.set_simulation_params(3, 3, "output", 0.1, 4, 4, 1, 1.0, 2, 1, 1, 0, 200, "null")
		self.coal.set_map_files("null", fine_file="sample/SA_sample.tif")
		self.coal.detect_map_dimensions()
		# self.coal.set_map_parameters("null", 10, 10, "sample/PALSAR_CONGO_SAMPLE.tif", 10, 10, 0, 0, "null", 20, 20, 0, 0, 1,"null", "null")
		self.coal.set_speciation_rates([0.1, 0.2])
		self.coal.complete_setup()
		self.coal.run_checks()
		self.coal.run_coalescence()
		self.tree.set_database("output/SQL_data/data_3_3.db")
		self.tree.calculate_octaves()
		self.tree.calculate_richness()

	def test_sim_params_stored(self):
		"""
		Tests the full simulation setup, checking species richness is correct and species abundance calculations are
		correct.
		:return:
		"""
		params = list(self.tree.get_simulation_parameters())
		params_compare = [3, 3, 'output', 0.1, 4.0, 4.0, 1, 1.0, 2.0, 1.0, 1, 0.0, 200.0, 'null', 'null', 24, 24, 0,
		                  0, 1.0, 'sample/SA_sample.tif', 24, 24, 0, 0, "null", 24, 24, 'null', 'null', 1]
		self.assertListEqual(params, params_compare)
		self.assertEqual(self.tree.get_job()[0], 3)
		self.assertEqual(self.tree.get_job()[1], 3)

	def test_richness(self):
		"""
		Tests that the richness stored in the SQL file is correct.
		Note that this is actually a test of both the c++ (NECSim) and the python front-end.
		"""
		self.assertEqual(self.tree.get_richness(speciation_rate=0.1), 278)
		self.assertEqual(self.tree.get_richness(speciation_rate=0.2), 338)

	def test_richness_landscape(self):
		"""
		Tests the landscape richness function which calculates landscape richness for each time and speciation rate.
		"""
		richness = self.tree.get_landscape_richness()
		richness_01 = [x[2] for x in richness if x[0] == 0.1][0]
		richness_02 = [x[2] for x in richness if x[0] == 0.2][0]
		self.assertEqual(richness_01, 278)
		self.assertEqual(richness_02, 338)


class CoalTifTestCoarse(unittest.TestCase):
	"""
	Tests the coarse tif reading and correct parameter detection.
	This requires the files SA_sample_fine.tif and SA_sample_coarse.tif in sample/
	"""

	@classmethod
	def setUpClass(self):
		"""
		Sets up the Coalescence object test case.
		"""
		self.coal = Coalescence()
		self.tree = Tree()
		self.coal.setup(coalescence_simulator="build/nv/fat_tailed/./NECSim")
		self.coal.set_simulation_params(4, 4, "output", 0.1, 4, 4, 1, 1.0, 2, 1, 1, 0, 200, "null")
		self.coal.set_map_files("null", fine_file="sample/SA_sample_fine.tif",
		                        coarse_file="sample/SA_sample_coarse.tif")
		self.coal.detect_map_dimensions()
		# print(self.coal.coarse_map.x_offset)
		# print(self.coal.coarse_map.y_offset)
		# print(self.coal.fine_map.x_offset)
		# self.coal.set_map_parameters("null", 10, 10, "sample/PALSAR_CONGO_SAMPLE.tif", 10, 10, 0, 0, "null", 20, 20, 0, 0, 1,"null", "null")
		self.coal.set_speciation_rates([0.1, 0.2])
		self.coal.complete_setup()
		self.coal.run_checks()
		self.coal.run_coalescence()
		self.tree.set_database("output/SQL_data/data_4_4.db")
		self.tree.calculate_octaves()
		self.tree.calculate_richness()

	def test_sim_params_stored(self):
		"""
		Tests the full simulation setup, checking species richness is correct and species abundance calculations are
		correct.
		:return:
		"""
		params = list(self.tree.get_simulation_parameters())
		params_compare = [4, 4, 'output', 0.1, 4.0, 4.0, 1, 1.0, 2.0, 1.0, 1, 0.0, 200.0, 'null',
		                  'sample/SA_sample_coarse.tif', 35, 41, 11, 14,
		                  1.0, 'sample/SA_sample_fine.tif', 13, 13, 0, 0, 13, 13, 'null', 'null']
		self.assertListEqual(params, params_compare)
		self.assertEqual(self.tree.get_job()[0], 4)
		self.assertEqual(self.tree.get_job()[1], 4)

	def test_richness(self):
		"""
		Tests that the richness stored in the SQL file is correct.
		Note that this is actually a test of both the c++ (NECSim) and the python front-end.
		"""
		self.assertEqual(self.tree.get_richness(speciation_rate=0.1), 94)
		self.assertEqual(self.tree.get_richness(speciation_rate=0.2), 111)

	def test_richness_landscape(self):
		"""
		Tests the landscape richness function which calculates landscape richness for each time and speciation rate.
		"""
		richness = self.tree.get_landscape_richness()
		richness_01 = [x[2] for x in richness if x[0] == 0.1][0]
		richness_02 = [x[2] for x in richness if x[0] == 0.2][0]
		self.assertEqual(richness_01, 94)
		self.assertEqual(richness_02, 111)


class CoalTifTestCoarse(unittest.TestCase):
	"""
	Tests the coarse tif reading and correct parameter detection.
	This requires the files SA_sample_fine.tif and SA_sample_coarse.tif in sample/
	"""

	@classmethod
	def setUpClass(self):
		"""
		Sets up the Coalescence object test case.
		"""
		self.coal = Coalescence()
		self.tree = Tree()
		self.coal.setup(coalescence_simulator="build/nv/fat_tailed/./NECSim")
		self.coal.set_simulation_params(4, 4, "output", 0.1, 4, 4, 1, 1.0, 2, 1, 1, 0, 200, "null")
		self.coal.set_map_files("null", fine_file="sample/SA_sample_fine.tif",
		                        coarse_file="sample/SA_sample_coarse.tif")
		self.coal.detect_map_dimensions()
		# print(self.coal.coarse_map.x_offset)
		# print(self.coal.coarse_map.y_offset)
		# print(self.coal.fine_map.x_offset)
		# self.coal.set_map_parameters("null", 10, 10, "sample/PALSAR_CONGO_SAMPLE.tif", 10, 10, 0, 0, "null", 20, 20, 0, 0, 1,"null", "null")
		self.coal.set_speciation_rates([0.1, 0.2])
		self.coal.complete_setup()
		self.coal.run_checks()
		self.coal.run_coalescence()
		self.tree.set_database("output/SQL_data/data_4_4.db")
		self.tree.calculate_octaves()
		self.tree.calculate_richness()

	def test_sim_params_stored(self):
		"""
		Tests the full simulation setup, checking species richness is correct and species abundance calculations are
		correct.
		:return:
		"""
		params = list(self.tree.get_simulation_parameters())
		params_compare = [4, 4, 'output', 0.1, 4.0, 4.0, 1, 1.0, 2.0, 1.0, 1, 0.0, 200.0, 'null',
		                  'sample/SA_sample_coarse.tif', 35, 41, 11, 14,
		                  1.0, 'sample/SA_sample_fine.tif', 13, 13, 0, 0, "null", 13, 13, 'null', 'null', 1]
		self.assertListEqual(params, params_compare)
		self.assertEqual(self.tree.get_job()[0], 4, msg="Job number not stored correctly.")
		self.assertEqual(self.tree.get_job()[1], 4, msg="Job number not stored correctly.")

	def test_richness(self):
		"""
		Tests that the richness stored in the SQL file is correct.
		Note that this is actually a test of both the c++ (NECSim) and the python front-end.
		"""
		self.assertEqual(self.tree.get_richness(speciation_rate=0.1), 94,
		                 msg="Species richness not correctly calculated.")
		self.assertEqual(self.tree.get_richness(speciation_rate=0.2), 111,
		                 msg="Species richness not correctly calculated.")

	def test_richness_landscape(self):
		"""
		Tests the landscape richness function which calculates landscape richness for each time and speciation rate.
		"""
		richness = self.tree.get_landscape_richness()
		richness_01 = [x[2] for x in richness if x[0] == 0.1][0]
		richness_02 = [x[2] for x in richness if x[0] == 0.2][0]
		self.assertEqual(richness_01, 94, msg="Species richness not correctly calculated.")
		self.assertEqual(richness_02, 111, msg="Species richness not correctly calculated.")


class CoalAnalyseTest(unittest.TestCase):
	"""
	Tests the coarse tif reading and correct parameter detection.
	This requires the files SA_sample_fine.tif and SA_sample_coarse.tif in sample/
	"""

	@classmethod
	def setUpClass(self):
		"""
		Sets up the Coalescence object test case.
		"""
		self.test = Tree()
		self.test.set_database("sample/sample.db")
		self.test.import_comparison_data("sample/PlotBiodiversityMetrics.db")
		self.test.calculate_comparison_octaves(True)
		self.test.clear_calculations()
		self.test.calculate_fragment_richness()
		self.test.calculate_fragment_octaves()
		self.test.calculate_octaves_error()

	@classmethod
	def tearDownClass(cls):
		"""
		Removes the files from output."
		:return:
		"""
		cls.test.clear_calculations()

	def test_fragment_octaves(self):
		num = self.test.cursor.execute(
			"SELECT number FROM FRAGMENT_OCTAVES WHERE fragment == 'P09' AND octave == 0"
			" AND ROUND(speciation_rate,6)=0.1").fetchall()[0][0]
		self.assertEqual(num, 7, msg="Fragment octaves not correctly calculated.")
		num = self.test.cursor.execute(
			"SELECT number FROM FRAGMENT_OCTAVES WHERE fragment == 'P09' AND octave == 0 "
			"AND ROUND(speciation_rate,6)=0.2").fetchall()[0][0]
		self.assertEqual(num, 7, msg="Fragment octaves not correctly calculated.")
		num = self.test.cursor.execute(
			"SELECT number FROM FRAGMENT_OCTAVES WHERE fragment == 'cerrogalera' AND octave == 1 "
			"AND ROUND(speciation_rate,6)=0.1").fetchall()[0][0]
		self.assertEqual(num, 3, msg="Fragment octaves not correctly calculated.")
		num = self.test.cursor.execute(
			"SELECT number FROM FRAGMENT_OCTAVES WHERE fragment == 'whole' AND octave == 1 "
			"AND ROUND(speciation_rate,6)=0.2").fetchall()[0][0]
		self.assertEqual(num, 221, msg="Fragment octaves not correctly calculated.")

	def test_fragment_abundances(self):
		"""
		Tests that fragment abundances are produced properly by the fragment detection functions.

		"""
		num = self.test.cursor.execute(
			"SELECT COUNT(fragment) FROM FRAGMENT_ABUNDANCES WHERE fragment == 'P09' "
			" AND ROUND(speciation_rate,6)=0.1").fetchall()[0][0]
		self.assertEqual(num, 9, msg="Fragment abundances not correctly calculated.")
		num = self.test.cursor.execute(
			"SELECT COUNT(fragment) FROM FRAGMENT_ABUNDANCES WHERE fragment == 'P09' "
			"AND ROUND(speciation_rate,6)=0.2").fetchall()[0][0]
		self.assertEqual(num, 9, msg="Fragment abundances not correctly calculated.")
		num = self.test.cursor.execute(
			"SELECT COUNT(fragment) FROM FRAGMENT_ABUNDANCES WHERE fragment == 'cerrogalera' "
			"AND ROUND(speciation_rate,6)=0.1").fetchall()[0][0]
		self.assertEqual(num, 9, msg="Fragment abundances not correctly calculated.")

	def test_species_abundances(self):
		"""
		Tests that the produced species abundances are correct by comparing species richness.
		"""
		num = self.test.cursor.execute(
			"SELECT COUNT(species_id) FROM SPECIES_ABUNDANCES WHERE ROUND(speciation_rate,6)=0.2").fetchall()[0][0]
		self.assertEqual(num, 1029, msg="Species abundances not correctly calculated.")
		num = self.test.cursor.execute(
			"SELECT COUNT(species_id) FROM SPECIES_ABUNDANCES WHERE ROUND(speciation_rate,6)=0.1").fetchall()[0][0]
		self.assertEqual(num, 884, msg="Species abundances not correctly calculated.")

	def test_species_locations(self):
		"""
		Tests that species locations have been correctly assigned.
		"""
		num = self.test.cursor.execute("SELECT species_id from SPECIES_LOCATIONS WHERE x==1662 and y==4359 "
		                               "AND ROUND(speciation_rate,6)==0.1").fetchall()
		self.assertEqual(len(set(num)), 2, msg="Species locations not correctly assigned")


class CoalConfigReadWrite(unittest.TestCase):
	"""
	Tests the reading and writing to a config text file.
	Independently tests the main config, map config and time config writing ability.
	"""

	@classmethod
	def setUpClass(self):
		"""
		Sets up the Coalescence object test case.
		"""
		self.coal = Coalescence()
		self.tree = Tree()
		self.coal.setup(coalescence_simulator="build/nv/fat_tailed/./NECSim")
		self.coal.set_simulation_params(6, 6, "output", 0.1, 4, 4, 1, 1.0, 200, 1, 1, 0, 200, "null")
		self.coal.set_map_files("null", fine_file="sample/SA_sample_fine.tif",
		                        coarse_file="sample/SA_sample_coarse.tif")
		self.coal.detect_map_dimensions()
		self.coal.add_sample_time(0.0)
		self.coal.add_sample_time(1.0)
		self.coal.create_temporal_sampling_config("output/tempconf1.txt")
		self.coal.create_map_config("output/mapconf1.txt")
		self.coal.create_config("output/conf1.txt")
		# print(self.coal.coarse_map.x_offset)
		# print(self.coal.coarse_map.y_offset)
		# print(self.coal.fine_map.x_offset)
		# self.coal.set_map_parameters("null", 10, 10, "sample/PALSAR_CONGO_SAMPLE.tif", 10, 10, 0, 0, "null", 20, 20, 0, 0, 1,"null", "null")
		self.coal.set_speciation_rates([0.1, 0.2])
		self.coal.complete_setup()
		self.coal.run_checks()

	# self.coal.run_coalescence()
	# self.tree.set_database("output/SQL_data/data_6_6.db")
	# self.tree.calculate_octaves()
	# self.tree.calculate_richness()

	@classmethod
	def tearDownClass(cls):
		"""
		Removes the files from output."
		:return:
		"""
		os.remove("output/mapconf.txt")

	def testConfigWrite(self):
		"""
		Tests that the main configuration file has been correctly generated.
		"""
		with open("output/conf.txt", "r") as mapconf:
			lines = mapconf.readlines()
			lines = [x.strip() for x in lines]
			self.assertEqual(lines[0], "[main]")
			self.assertEqual(lines[1].replace(" ", ""), "job_num=6")
			self.assertEqual(lines[2].replace(" ", ""), "job_type=6")
			self.assertEqual(lines[12].replace(" ", ""), "time_config=output/tempconf.txt")

	def testMapConfigWrite(self):
		"""
		Tests the map config output to check output is correct.
		"""
		self.coal.add_pristine_map(fine_map="sample/SA_sample_fine_pristine1.tif",
		                           coarse_map="sample/SA_sample_coarse_pristine1.tif",
		                           time=1, rate=0.5)
		self.coal.add_pristine_map(fine_map="sample/SA_sample_fine_pristine2.tif",
		                           coarse_map="sample/SA_sample_coarse_pristine2.tif",
		                           time=4, rate=0.7)
		self.coal.create_map_config("output/mapconf2.txt")
		with open("output/mapconf2.txt", "r") as mapconf:
			lines = mapconf.readlines()
			lines = [x.strip() for x in lines]
			self.assertEqual(lines[0], "[sample_grid]")
			self.assertEqual(lines[1].replace(" ", ""), "path=null", msg="Config file doesn't produce expected output.")
			self.assertEqual(lines[6].replace(" ", ""), "[fine_map]",
			                 msg="Config file doesn't produce expected output.")
			self.assertEqual(lines[7].replace(" ", ""), "path=sample/SA_sample_fine.tif",
			                 msg="Config file doesn't produce expected output.")
			self.assertEqual(lines[8].replace(" ", ""), "x=13", msg="Config file doesn't produce expected output.")
			self.assertEqual(lines[9].replace(" ", ""), "y=13", msg="Config file doesn't produce expected output.")
			self.assertEqual(lines[10].replace(" ", ""), "x_off=0", msg="Config file doesn't produce expected output.")
			self.assertEqual(lines[11].replace(" ", ""), "y_off=0", msg="Config file doesn't produce expected output.")

	def testTimeConfigWrite(self):
		"""
		Tests the map config writing is correct.
		"""
		with open("output/tempconf.txt", "r") as f:
			lines = f.readlines()
			lines = [x.strip().replace(" ", "") for x in lines]
			self.assertEqual(lines[0], "[main]", msg="Time config file doesn't produce expected output.")
			self.assertEqual(lines[1], "time0=0.0", msg="Time config file doesn't produce expected output.")
			self.assertEqual(lines[2], "time1=1.0", msg="Time config file doesn't produce expected output.")


class CoalSampleRun(unittest.TestCase):
	"""
	Test a simple run on a landscape using sampling
	"""

	@classmethod
	def setUpClass(self):
		"""
		Sets up the Coalescence object test case.
		"""
		self.coal = Coalescence()
		self.tree = Tree()
		self.coal.setup(coalescence_simulator="build/nv/norm/./NECSim")
		self.coal.set_simulation_params(job_num=6, job_type=8, output_directory="output", min_speciation_rate=0.5,
		                                zfat=4, dispersal=4, deme=1, sample_size=0.1, max_time=2, lambda_value=1,
		                                min_num_species=1, forest_change_param=0, pristine_forest=200,
		                                time_config_file="null")
		# self.coal.set_simulation_params(6, 6, "output", 0.5, 4, 4, 1, 0.1, 1, 1, 200, 0, 200, "null")
		self.coal.set_map_files(sample_file="sample/SA_samplemaskINT.tif", fine_file="sample/SA_sample_fine.tif",
		                        coarse_file="sample/SA_sample_coarse.tif")
		self.coal.detect_map_dimensions()
		self.coal.create_map_config("output/mapconf.txt")
		self.coal.create_config("output/conf.txt")
		self.coal.set_speciation_rates([0.5, 0.7])
		self.coal.complete_setup()
		self.coal.run_checks()
		self.coal.run_coalescence()
		self.tree.set_database("output/SQL_data/data_8_6.db")
		self.tree.set_speciation_params(record_spatial="T", record_fragments="F", speciation_rates=[0.6, 0.7],
		                                sample_file="null", time_config_file="output/tempconf.txt")
		self.tree.apply_speciation()
		self.tree.calculate_octaves()
		self.tree.calculate_richness()

	def testSampleRichness(self):
		"""
		Tests that the simulation using sampling returns the correct species richness.
		Also tests that both methods of obtaining species richness work.
		"""
		self.tree.calculate_richness()
		self.assertEqual(self.tree.get_landscape_richness(0.5, 0.0), 983)
		self.assertEqual(self.tree.get_landscape_richness(0.7, 0.0), 992)
		self.assertEqual(self.tree.get_landscape_richness(0.5, 0.0), self.tree.get_richness(0.5, 0.0))
		self.assertEqual(self.tree.get_landscape_richness(0.7, 0.0), self.tree.get_richness(0.7, 0.0))
		self.assertEqual(self.tree.get_landscape_richness(0.8, 0.0), self.tree.get_richness(0.8, 0.0))
		self.assertEqual(self.tree.get_landscape_richness(0.5, 20), self.tree.get_richness(0.5, 20))


class CoalPauseTest(unittest.TestCase):
	"""
	Test a simple run on a landscape using sampling
	"""

	@classmethod
	def setUpClass(self):
		"""
		Sets up the Coalescence object test case.
		"""
		self.coal = Coalescence()
		self.coal2 = Coalescence()
		self.tree2 = Tree()
		self.coal.setup(coalescence_simulator="build/nv/norm/./NECSim")
		self.coal.set_simulation_params(job_num=9, job_type=6, output_directory="output", min_speciation_rate=0.05,
		                                zfat=4, dispersal=4, deme=1, sample_size=0.1, max_time=0.0,
		                                lambda_value=1, min_num_species=1, forest_change_param=0, pristine_forest=200,
		                                time_config_file="null")
		# self.coal.set_simulation_params(6, 6, "output", 0.5, 4, 4, 1, 0.1, 1, 1, 200, 0, 200, "null")
		self.coal.set_map_files(sample_file="sample/SA_samplemaskINT.tif", fine_file="sample/SA_sample_fine.tif",
		                        coarse_file="sample/SA_sample_coarse.tif")
		self.coal.detect_map_dimensions()
		self.coal.create_map_config("output/mapconf.txt")
		self.coal.create_config("output/conf.txt")
		self.coal.complete_setup()
		self.coal.run_checks()
		self.coal.run_coalescence()
		self.coal2.setup(coalescence_simulator="build/nv/norm/./NECSim")
		self.coal2.set_simulation_params(job_num=9, job_type=7, output_directory="output", min_speciation_rate=0.05,
		                                 zfat=4, dispersal=4, deme=1, sample_size=0.1, max_time=100, lambda_value=1,
		                                 min_num_species=1, forest_change_param=0, pristine_forest=200,
		                                 time_config_file="null")
		# self.coal.set_simulation_params(6, 6, "output", 0.5, 4, 4, 1, 0.1, 1, 1, 200, 0, 200, "null")
		self.coal2.set_map_files(sample_file="sample/SA_samplemaskINT.tif", fine_file="sample/SA_sample_fine.tif",
		                         coarse_file="sample/SA_sample_coarse.tif")
		self.coal2.detect_map_dimensions()
		self.coal2.create_map_config("output/mapconf.txt")
		self.coal2.create_config("output/conf.txt")
		self.coal2.set_speciation_rates([0.5, 0.7])

		self.coal2.complete_setup()
		self.coal2.run_checks()
		self.coal2.run_coalescence()
		self.tree2.set_database("output/SQL_data/data_7_9.db")
		self.tree2.set_speciation_params(record_spatial="T", record_fragments="F", speciation_rates=[0.6, 0.7],
		                                 sample_file="null", time_config_file="output/tempconf.txt")
		self.tree2.apply_speciation()

		# self.tree2.calculate_octaves()
		# self.tree2.calculate_richness()
		self.tree1 = Tree()

	def testCanPause(self):
		"""
		Tests that simulations can pause executation and correctly store their state to the SQL database (for in-process
		analysis). Checks that the SQL database has correctly written the simulation parameters and that errors are
		thrown when one tries to connect to an incomplete simulation.
		"""
		tree2 = Tree()
		with self.assertRaises(IOError):
			tree2.set_database("output/SQL_data/data_6_9.db")
		actual_sim_parameters = [6, 9, 'output', 0.05, 4.0, 4.0, 1, 0.1, 0.0, 1.0, 1, 0.0, 200.0,
		                         'null',
		                         'sample/SA_sample_coarse.tif', 35, 41, 11, 14, 1.0, 'sample/SA_sample_fine.tif',
		                         13, 13, 0, 0, 'sample/SA_samplemaskINT.tif', 13, 13, 'null', 'null', 0]
		self.assertListEqual(list(tree2.get_simulation_parameters()), actual_sim_parameters)

	def testCanResume(self):
		"""
		Tests that simulations can resume execution.
		"""
		self.coal.resume_sim("output/", 9, 6, 10)
		self.tree1.set_database("output/SQL_data/data_6_9.db")
		self.coal.set_speciation_rates([0.5, 0.7])
		self.tree1.set_speciation_params(record_spatial="T", record_fragments="F", speciation_rates=[0.6, 0.7],
		                                 sample_file="null", time_config_file="output/tempconf.txt")
		self.tree1.apply_speciation()
		actual_sim_parameters = [6, 9, 'output', 0.05, 4.0, 4.0, 1, 0.1, 10.0, 1.0, 1, 0.0, 200.0,
		                         'null',
		                         'sample/SA_sample_coarse.tif', 35, 41, 11, 14, 1.0, 'sample/SA_sample_fine.tif',
		                         13, 13, 0, 0, 'sample/SA_samplemaskINT.tif', 13, 13, 'null', 'null', 1]
		self.assertListEqual(list(self.tree1.get_simulation_parameters()), actual_sim_parameters)
		self.assertEqual(self.coal.get_richness(), self.coal2.get_richness())

	def testPauseSimMatchesSingleRunSim(self):
		"""
		Tests that the two simulations (either pausing, then resuming, or just running straight to completion) produce
		identical results. Checks using comparison of the SPECIES_LIST tables
		"""
		self.tree1.set_database("output/SQL_data/data_6_9.db")
		single_run_species_list = list(self.tree1.get_species_list())[-100:]
		pause_sim_species_list = list(self.tree2.get_species_list())[-100:]
		# print(pause_sim_species_list)
		# print(single_run_species_list)
		self.assertListEqual([[x[0:9], x[-2]] for x in pause_sim_species_list],
		                     [[x[0:9], x[-2]] for x in single_run_species_list])
		self.assertAlmostEqual(single_run_species_list[0][9], pause_sim_species_list[0][9], 16)

	# def testSampleRichness(self):
	# 	"""
	# 	Tests that the simulation using sampling returns the correct species richness.
	# 	Also tests that both methods of obtaining species richness work.
	# 	"""
	# 	self.coal.set_speciation_rates([0.5, 0.7])
	# 	self.coal.set_speciation_params(file="output/SQL_data/data_9_6.db", record_spatial="T",
	# 									record_fragments="F", speciation_rates=[0.6, 0.7],
	# 									sample_file="null", time_config_file="output/tempconf.txt")
	# 	self.coal.apply_speciation()
	# 	self.tree1.calculate_richness()
	#
	# 	self.assertEqual(self.tree1.get_landscape_richness(0.5, 0.0), 2318, msg="Landscape richness is not as expected.")
	# 	self.assertEqual(self.tree1.get_landscape_richness(0.7, 0.0), 2350, msg="Landscape richness is not as expected.")
	# 	self.assertEqual(self.tree1.get_landscape_richness(0.5, 0.0), self.tree.get_richness(0.5, 0.0),
	# 					 msg="Landscape richness is not as expected.")
	# 	self.assertEqual(self.tree1.get_landscape_richness(0.7, 0.0), self.tree.get_richness(0.7, 0.0),
	# 					 msg="Landscape richness is not as expected.")
	# 	self.assertEqual(self.tree1.get_landscape_richness(0.8, 0.0), self.tree.get_richness(0.8, 0.0),
	# 					 msg="Landscape richness is not as expected.")
	# 	self.assertEqual(self.tree1.get_landscape_richness(0.5, 20), self.tree.get_richness(0.5, 20),
	# 					 msg="Landscape richness is not as expected.")


class CoalComplexRun(unittest.TestCase):
	"""
	Tests a complex run over multiple historic landscapes with multiple sampling points and using the full config file
	options. Uses a normal distribution and 10% sampling for quicker calculations.
	"""

	@classmethod
	def setUpClass(self):
		"""
		Sets up the Coalescence object test case.
		"""
		self.coal = Coalescence()
		self.tree = Tree()
		self.coal.setup(coalescence_simulator="build/nv/norm/./NECSim")
		self.coal.set_simulation_params(job_num=6, job_type=6, output_directory="output", min_speciation_rate=0.5,
		                                zfat=4, dispersal=4, deme=1, sample_size=0.1, max_time=1, lambda_value=1,
		                                min_num_species=1, forest_change_param=0, pristine_forest=200,
		                                time_config_file="null")
		# self.coal.set_simulation_params(6, 6, "output", 0.5, 4, 4, 1, 0.1, 1, 1, 200, 0, 200, "null")
		self.coal.set_map_files("null", fine_file="sample/SA_sample_fine.tif",
		                        coarse_file="sample/SA_sample_coarse.tif")
		self.coal.detect_map_dimensions()
		self.coal.add_sample_time(0.0)
		self.coal.add_sample_time(1.0)
		self.coal.create_temporal_sampling_config("output/tempconf.txt")
		self.coal.create_map_config("output/mapconf.txt")
		self.coal.create_config("output/conf.txt")
		# print(self.coal.coarse_map.x_offset)
		# print(self.coal.coarse_map.y_offset)
		# print(self.coal.fine_map.x_offset)
		# self.coal.set_map_parameters("null", 10, 10, "sample/PALSAR_CONGO_SAMPLE.tif", 10, 10, 0, 0, "null", 20, 20, 0, 0, 1,"null", "null")
		self.coal.set_speciation_rates([0.5])

		self.coal.complete_setup()
		self.coal.run_checks()
		self.coal.run_coalescence()

		self.tree.set_database("output/SQL_data/data_6_6.db")
		self.tree.set_speciation_params(record_spatial="T", record_fragments="F", speciation_rates=[0.6, 0.7],
		                                sample_file="null", time_config_file="output/tempconf.txt")
		self.tree.apply_speciation()
		self.tree.calculate_octaves()
		self.tree.calculate_richness()

	@classmethod
	def tearDownClass(cls):
		"""
		Removes the files from output."
		:return:
		"""
		pass  # rmtree("output", True)

	def testComplexRichness(self):
		"""
		Tests that the complex simulation setup returns the correct species richness.
		Also tests that both methods of obtaining species richness work.
		"""
		self.tree.calculate_richness()
		self.assertEqual(self.tree.get_landscape_richness(0.5, 0.0), 3616, msg="Landscape richness is not as expected.")
		self.assertEqual(self.tree.get_landscape_richness(0.6, 0.0), 3658, msg="Landscape richness is not as expected.")
		self.assertEqual(self.tree.get_landscape_richness(0.7, 0.0), 3680, msg="Landscape richness is not as expected.")
		self.assertEqual(self.tree.get_landscape_richness(0.8, 0.0), 0, msg="Landscape richness is not as expected.")
		self.assertEqual(self.tree.get_landscape_richness(0.5, 0.0), self.tree.get_richness(0.5, 0.0),
		                 msg="Landscape richness is not as expected.")
		self.assertEqual(self.tree.get_landscape_richness(0.6, 0.0), self.tree.get_richness(0.6, 0.0),
		                 msg="Landscape richness is not as expected.")
		self.assertEqual(self.tree.get_landscape_richness(0.7, 1.0), self.tree.get_richness(0.7, 1.0),
		                 msg="Landscape richness is not as expected.")
		self.assertEqual(self.tree.get_landscape_richness(0.8, 0.0), self.tree.get_richness(0.8, 0.0),
		                 msg="Landscape richness is not as expected.")
		self.assertEqual(self.tree.get_landscape_richness(0.5, 20), self.tree.get_richness(0.5, 20),
		                 msg="Landscape richness is not as expected.")

	def testSimulationParametersStored(self):
		"""
		Tests that the simulation parameters have been stored correctly, and that the functions for getting specific
		parameters work properly.
		"""
		simulation_parameters = list(self.tree.get_simulation_parameters())
		actual_sim_parameters = [6, 6, 'output', 0.5, 4.0, 4.0, 1, 0.1, 1.0, 1.0, 1, 0.0, 200.0, 'output/tempconf.txt',
		                         'sample/SA_sample_coarse.tif', 35, 41, 11, 14, 1.0, 'sample/SA_sample_fine.tif',
		                         13, 13, 0, 0, 'null', 13, 13, 'null', 'null', 1]
		self.assertListEqual(simulation_parameters, actual_sim_parameters)
		self.assertEqual(self.tree.get_job()[0], 6)
		self.assertEqual(self.tree.get_job()[1], 6)


class CoalComplexRun2(unittest.TestCase):
	"""
	Tests a complex run over multiple historic landscapes with multiple sampling points and using partial config file
	options (config for temporal and map options, not for full simulation options).
	Uses a normal distribution and 10% sampling for quicker calculations.
	"""

	@classmethod
	def setUpClass(self):
		"""
		Sets up the Coalescence object test case.
		"""
		self.coal = Coalescence()
		self.tree = Tree()
		self.coal.setup(coalescence_simulator="build/nv/norm/./NECSim")
		self.coal.set_simulation_params(job_num=6, job_type=7, output_directory="output", min_speciation_rate=0.5,
		                                zfat=4, dispersal=4, deme=1, sample_size=0.1, max_time=1, lambda_value=1,
		                                min_num_species=1, forest_change_param=0, pristine_forest=200,
		                                time_config_file="null")
		# self.coal.set_simulation_params(6, 6, "output", 0.5, 4, 4, 1, 0.1, 1, 1, 200, 0, 200, "null")
		self.coal.set_map_files("null", fine_file="sample/SA_sample_fine.tif",
		                        coarse_file="sample/SA_sample_coarse.tif")
		self.coal.detect_map_dimensions()
		self.coal.add_sample_time(0.0)
		self.coal.add_sample_time(1.0)
		self.coal.create_temporal_sampling_config("output/tempconf.txt")
		self.coal.create_map_config("output/mapconf.txt")
		# self.coal.create_config("output/conf.txt")
		# print(self.coal.coarse_map.x_offset)
		# print(self.coal.coarse_map.y_offset)
		# print(self.coal.fine_map.x_offset)
		# self.coal.set_map_parameters("null", 10, 10, "sample/PALSAR_CONGO_SAMPLE.tif", 10, 10, 0, 0, "null", 20, 20, 0, 0, 1,"null", "null")
		self.coal.set_speciation_rates([0.5])

		self.coal.complete_setup()
		self.coal.run_checks()
		self.coal.run_coalescence()
		self.tree.set_database("output/SQL_data/data_7_6.db")
		self.tree.set_speciation_params(record_spatial="T", record_fragments="F", speciation_rates=[0.6, 0.7],
		                                sample_file="null", time_config_file="output/tempconf.txt")
		self.tree.apply_speciation()
		self.tree.calculate_octaves()
		self.tree.calculate_richness()

	@classmethod
	def tearDownClass(cls):
		"""
		Removes the files from output."
		:return:
		"""
		pass  # rmtree("output", True)

	def testComplexRichness(self):
		"""
		Tests that the complex simulation setup returns the correct species richness.
		Also tests that both methods of obtaining species richness work.
		"""
		self.tree.calculate_richness()
		self.assertEqual(self.tree.get_landscape_richness(0.5, 0.0), 3616)
		self.assertEqual(self.tree.get_landscape_richness(0.6, 0.0), 3658)
		self.assertEqual(self.tree.get_landscape_richness(0.7, 0.0), 3680)
		self.assertEqual(self.tree.get_landscape_richness(0.8, 0.0), 0)
		self.assertEqual(self.tree.get_landscape_richness(0.5, 0.0), self.tree.get_richness(0.5, 0.0))
		self.assertEqual(self.tree.get_landscape_richness(0.6, 0.0), self.tree.get_richness(0.6, 0.0))
		self.assertEqual(self.tree.get_landscape_richness(0.7, 1.0), self.tree.get_richness(0.7, 1.0))
		self.assertEqual(self.tree.get_landscape_richness(0.8, 0.0), self.tree.get_richness(0.8, 0.0))
		self.assertEqual(self.tree.get_landscape_richness(0.5, 20), self.tree.get_richness(0.5, 20))

	# octaves = self.tree.get_fragment_octaves()
	# print(octaves)
	# self.assertEqual(octaves[0], 10)

	# class CoalFuncCheck(unittest.TestCase):
	# 	"""
	# 	Tests the basic functions of coalescence.py
	# 	"""
	# 	TODO finish this implementation
	# pass


class CoalFuncCheck(unittest.TestCase):
	"""
	Test the basic capabilities of coalescence
	"""

	@classmethod
	def setUpClass(self):
		self.coal = Coalescence()
		self.coal.set_map_files(sample_file="sample/SA_samplemaskINT.tif", fine_file="sample/SA_sample_fine.tif",
		                        coarse_file="sample/SA_sample_coarse.tif")
		self.coal.detect_map_dimensions()
		self.coal2 = Coalescence()
		self.coal2.set_map_files(sample_file="null", fine_file="sample/SA_sample_fine.tif",
		                         coarse_file="sample/SA_sample_coarse.tif")
		self.coal2.detect_map_dimensions()

	def testFineMapDimensions(self):
		"""
		Checks that the dimensions and offsets are properly calculated.
		"""
		self.assertEqual(self.coal.fine_map.x_offset, 0)
		self.assertEqual(self.coal.fine_map.y_offset, 0)
		self.assertAlmostEqual(self.coal.fine_map.x_res, 0.00833308, 5)
		self.assertAlmostEqual(self.coal.fine_map.y_res, -0.00833308, 5)
		self.assertEqual(self.coal.fine_map.x_size, 13)
		self.assertEqual(self.coal.fine_map.y_size, 13)

	def testFineMapDimensionsNull(self):
		"""
		Checks that the dimensions and offsets are properly calculated when there is a null map provided as the
		samplemask.
		"""
		self.assertEqual(self.coal2.fine_map.x_offset, 0)
		self.assertEqual(self.coal2.fine_map.y_offset, 0)
		self.assertAlmostEqual(self.coal2.fine_map.x_res, 0.00833308, 5)
		self.assertAlmostEqual(self.coal2.fine_map.y_res, -0.00833308, 5)
		self.assertEqual(self.coal2.fine_map.x_size, 13)
		self.assertEqual(self.coal2.fine_map.y_size, 13)

	def testCoarseMapDimensions(self):
		"""
		Checks that the dimensions and offsets are properly calculated.
		"""
		self.assertEqual(self.coal.coarse_map.x_offset, 11)
		self.assertEqual(self.coal.coarse_map.y_offset, 14)
		self.assertAlmostEqual(self.coal.coarse_map.x_res, 0.00833308, 5)
		self.assertAlmostEqual(self.coal.coarse_map.y_res, -0.00833308, 5)
		self.assertEqual(self.coal.coarse_map.x_size, 35)
		self.assertEqual(self.coal.coarse_map.y_size, 41)

	def testCoarseMapDimensionsNull(self):
		"""
		Checks that the dimensions and offsets are properly calculated when there is a null map provided as the
		samplemask.
		"""
		self.assertEqual(self.coal2.coarse_map.x_offset, 11)
		self.assertEqual(self.coal2.coarse_map.y_offset, 14)
		self.assertAlmostEqual(self.coal2.coarse_map.x_res, 0.00833308, 5)
		self.assertAlmostEqual(self.coal2.coarse_map.y_res, -0.00833308, 5)
		self.assertEqual(self.coal2.coarse_map.x_size, 35)
		self.assertEqual(self.coal2.coarse_map.y_size, 41)

	def testSimStart(self):
		"""
		Checks that the correct exceptions are raised when simulation is started without being properly setup
		"""
		with self.assertRaises(RuntimeError):
			self.coal.run_coalescence()
		with self.assertRaises(RuntimeError):
			self.coal.complete_setup()


class TestSimulationAnalysis(unittest.TestCase):
	"""
	Tests that the simulation can perform all required analyses, and that the correct errors are thrown if the object
	does not exist.
	"""

	@classmethod
	def setUpClass(self):
		self.coal = Coalescence()
		self.tree = Tree()
		self.coal.setup()
		self.coal.set_simulation_params(job_num=9, job_type=1, output_directory="output", min_speciation_rate=0.5,
		                                zfat=4, dispersal=4, deme=1, sample_size=0.1, max_time=2, lambda_value=1,
		                                min_num_species=1, forest_change_param=0, pristine_forest=200,
		                                time_config_file="null")
		# self.coal.set_simulation_params(6, 6, "output", 0.5, 4, 4, 1, 0.1, 1, 1, 200, 0, 200, "null")
		self.coal.set_map_files(sample_file="sample/SA_samplemaskINT.tif", fine_file="sample/SA_sample_fine.tif",
		                        coarse_file="sample/SA_sample_coarse.tif")
		self.coal.detect_map_dimensions()
		self.coal.create_map_config("output/mapconf.txt")
		self.coal.create_config("output/conf.txt")
		self.coal.complete_setup()
		self.coal.run_checks()
		self.coal.run_coalescence()
		# self.coal.set_speciation_rates([0.5, 0.7])
		self.tree.set_database("output/SQL_data/data_1_9.db")
		self.tree.set_speciation_params(record_spatial="T",
		                                record_fragments="sample/FragmentsTest.csv", speciation_rates=[0.5, 0.7],
		                                sample_file="null", time_config_file="null")
		self.tree.apply_speciation()
		self.tree.calculate_fragment_richness()
		self.tree.calculate_fragment_octaves()


	def testReadsFragmentsRichness(self):
		"""
		Tests that the fragment richness can be read correctly
		"""
		sim_params = self.tree.get_simulation_parameters()
		self.assertListEqual(sim_params, [1, 9, 'output', 0.5, 4.0, 4.0, 1, 0.1, 2.0, 1.0, 1, 0.0, 200.0, 'null',
		                                  'sample/SA_sample_coarse.tif', 35, 41, 11, 14, 1.0,
		                                  'sample/SA_sample_fine.tif', 13, 13, 0, 0, 'sample/SA_samplemaskINT.tif', 13,
		                                  13, 'null', 'null', 1])
		fragment2_richness = [0, "fragment2", 0.0, 0.5, 129]
		self.assertListEqual(self.tree.get_fragment_richness(fragment="fragment2", speciation_rate=0.5, time=0.0),
		                     fragment2_richness)
		octaves = self.tree.get_fragment_richness()
		self.assertListEqual(fragment2_richness, [x for x in octaves if x[0] == 0][0])

	def testFragmentRichnessRaiseError(self):
		"""
		Tests that the correct errors are raised when no fragment exists with that name, or with the specified
		speciation rate, or time. Also checks SyntaxErrors and sqlite3.OperationalErrors when no FRAGMENT_RICHNESS table
		exists.
		"""
		failtree = Tree()
		try:
			failtree.set_database("sample/failsample.db")
		except sqlite3.OperationalError:
			pass
		with self.assertRaises(sqlite3.OperationalError):
			failtree.get_fragment_richness()
		with self.assertRaises(RuntimeError):
			self.tree.get_fragment_richness(fragment="fragment4", speciation_rate=0.5, time=0.0)
		with self.assertRaises(SyntaxError):
			self.tree.get_fragment_richness(fragment="fragment4")
		with self.assertRaises(SyntaxError):
			self.tree.get_fragment_richness(speciation_rate=0.5)


	def testReadsFragmentOctaves(self):
		"""
		Tests that the fragment octaves can be read correctly.
		"""

		octaves = self.tree.get_fragment_octaves(fragment="fragment2", speciation_rate=0.5, time=0.0)
		all_octaves = self.tree.get_fragment_octaves()
		fragment2_octave = [0, "fragment2", 0.0, 0.5, 0, 128]
		self.assertListEqual(fragment2_octave, octaves[0])
		self.assertListEqual(fragment2_octave, [x for x in all_octaves if x[0] == 0][0])

	def testFragmentOctavesRaiseError(self):
		"""
		Tests that the correct errors are raised for different situations for reading fragment octaves
		"""
		failtree=Tree()
		try:
			failtree.set_database("sample/failsample.db")
		except sqlite3.OperationalError:
			pass
		with self.assertRaises(sqlite3.OperationalError):
			failtree.get_fragment_octaves(fragment="fragment4", speciation_rate=0.5, time=0.0)
		with self.assertRaises(RuntimeError):
			self.tree.get_fragment_octaves(fragment="fragment4", speciation_rate=0.5, time=0.0)
		with self.assertRaises(SyntaxError):
			self.tree.get_fragment_octaves(fragment="fragment4")
		with self.assertRaises(SyntaxError):
			self.tree.get_fragment_octaves(speciation_rate=0.5)



def main():
	"""
	Set the logging method, run the program compilation (if required) and test the install.

	.. note:: The working directory is changed to the package install location for the duration of this execution.
	:return:
	"""
	set_logging_method(logging_level=logging.WARNING, output=None)
	make_all_compile()
	test_install()


if __name__ == "__main__":
	main()
