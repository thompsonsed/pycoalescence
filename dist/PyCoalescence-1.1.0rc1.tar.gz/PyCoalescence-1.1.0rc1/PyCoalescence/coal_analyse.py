"""
Contains the operations for performing basic analysis on the output of a PyCoalescence simulation.
"""

import os
import subprocess
import logging

try:
	import sqlite3
except ImportError:
	# Python 3 compatibility
	import sqlite as sqlite3
import math
import warnings
import sys
# import pdb

from system_operations import execute_log_info, mod_directory


class Tree:
	"""
	Contains the coalescence tree and performs various calculations of different biodiversity metrics, which are then
	stored in the SQLite database.

	The general process is

	* Import the database (set_database()) and import the comparison data, if required (import_comparison_data())
	* Apply additional speciation rates (if required) using set_speciation_params() and apply_speciation()
	* Calculate required metrics (such as calculate_fragment_richness())
	* Save the required metrics to the SQL database (such as save_fragment_richness())
	* Optionally, calculate the goodness of fit (calculate_goodness_of_fit())

	"""

	def __init__(self, speciation_program=os.path.join(mod_directory, "build/default/SpeciationCounter")):
		"""
		Initiates the Tree object. By default, links to the SpeciationCounter program stored in
		build/default/SpeciationCounter, but optionally takes speciation_program as a path to an alternative program.

		:param speciation_program: the path to the alternative SpeciationCounter program.
		:return: None
		"""
		# speciation objects
		self.is_setup_speciation = False
		self.record_spatial = False
		self.time_config_file = "null"
		self.sample_file = "null"
		self.record_fragments = False
		self.speciation_simulator = None
		self.apply_speciation_rates = []
		# Other objects
		self.is_complete = False
		self.total_individuals = 0
		self.comparison_abundances_whole = None
		self.comparison_file = None
		self.file = None
		self.database = None
		self.cursor = None
		self.fragments = []
		self.times = []
		self.speciation_rates = []
		self.comparison_data = None
		self.comparison_abundances = None
		self.comparison_octaves = None
		self.setup(speciation_program)

	def setup(self, speciation_program=os.path.join(mod_directory, "build/default/SpeciationCounter")):
		"""
		Sets up the link to the SpeciationCounter program. Defaults to the build/default/SpeciationCounter
		:param speciation_program: optionally provide a path to an alternative SpeciationCounter program.
		:return: None
		"""
		self.speciation_simulator = speciation_program
		if not os.path.exists(self.speciation_simulator):
			raise IOError("Speciation simulator " + self.speciation_simulator +
						  " not found. Check file path and access.")

	def set_database(self, filename):
		"""
		Sets the database to the specified file and opens the sqlite connection.

		This must be done before any other operations can be performed and the
		file must exist.

		Note that this will throw an IOError if the simulation is not complete, as analysis can only be performed on
		complete simulations. However, the database WILL be set before the error is thrown, allowing for analysis of
		incomplete simulations if the error is handled correctly.

		:param filename: the SQLite database file to import
		"""
		if os.path.exists(filename):
			self.file = filename
			try:
				self.database = sqlite3.connect(filename)
			except sqlite3.OperationalError as e:
				self.database = None
				raise IOError("Error opening SQLite database: " + e.message)
			# Now make sure that the simulation has been completed
			try:
				self.cursor = self.database.cursor()
				complete = bool(self.cursor.execute("SELECT sim_complete FROM SIMULATION_PARAMETERS").fetchone()[0])
				if not complete:
					self.is_complete = False
					raise IOError(filename + " is not a complete simulation. Please finish " \
											 "simulation before performing analysis.")
				else:
					self.is_complete = True
			except sqlite3.OperationalError as soe:
				soe.message = "Error checking simulation was complete: " + soe.message
				raise soe
		else:
			raise IOError("File " + filename + " does not exist.")

	def set_speciation_params(self, record_spatial, record_fragments, speciation_rates, sample_file=None,
							  time_config_file=None):
		"""

		Set the parameters for the application of speciation rates. If no config files or time_config files are provided,
		they will be taken from the main coalescence simulation.

		:rtype: None
		:param bool, str record_spatial: a boolean of whether to record spatial data
		:param str record_fragments: either a csv file containing fragment data, or T/F for whether fragments should be
			calculated from squares of continuous habitat.
		:param list speciation_rates: a list of speciation rates to apply
		:param str sample_file: a sample tif or csv specifying the sampling mask
		:param str time_config_file: a configuration file of temporal sampling points
		"""
		if isinstance(record_spatial, bool):
			if record_spatial:
				record_spatial = "T"
			else:
				record_spatial = "F"
		if speciation_rates is None:
			raise RuntimeError("No speciation rates supplied: requires at least 1 for analysis.")
		if not self.is_setup_speciation:
			self.record_spatial = record_spatial
			self.record_fragments = record_fragments
			if sample_file is None:
				warnings.warn("No sample file provided, defaulting to null.", RuntimeWarning)
				self.sample_file = "null"
			else:
				self.sample_file = sample_file
			if time_config_file is None:
				warnings.warn("No time config file provided, defaulting to null.", RuntimeWarning)
				self.time_config_file = "null"
			else:
				self.time_config_file = time_config_file
			self.apply_speciation_rates = [str(x) for x in speciation_rates]
		else:
			warnings.warn("Speciation parameters already set.", RuntimeWarning)

	def apply_speciation(self):
		"""
		Creates the list of speciation options and performs the speciation analysis by calling SpeciationCounter.
		This must be run after the main coalescence simulations are complete.
		It will create additional fields and tables in the SQLite database which contains the requested data.
		"""
		# Check file exists
		if not os.path.exists(self.file):
			warnings.warn(str("Check file existance for " + self.speciation_file +
							  ". Potential lack of access (verify that definition is a relative path)."),
						  RuntimeWarning)
		sim_list = [self.speciation_simulator, self.file, self.record_spatial, self.sample_file,
					self.time_config_file, self.record_fragments]
		sim_list.extend(self.apply_speciation_rates)
		# lSpeciation = ["../NECSim/./Speciation_Counter"]
		# lSpeciation.extend([file, "T", "../../Data/Maps/Panama_run/BCIPlotMask.csv",
		# 					"../../Data/Configs/TimeConfigs/TimeConfig_BCI_7x5year.txt"])
		# speciation_str = [str(x) for x in speciation]
		# lSpeciation.extend(speciation_str)
		sim_list_str = [str(x) for x in sim_list]
		try:
			execute_log_info(sim_list_str)
		except subprocess.CalledProcessError as cpe:
			warnings.warn("CalledProcessError while applying speciation rates: " +
			              ",".join([str(x) for x in sim_list_str]))
			raise cpe

	def get_richness(self, speciation_rate=None, time=None):
		"""
		Get the system richness for the supplied speciation rate and time.
		Note that a richness of 0 is returned if there has been some problem; it is assumed that species richness
		will be above 0 for any simulation.

		Note that the values generated by this method should be identical to those produced by self.get_landscape_richness()

		:param speciation_rate: the required speciation rate
		:param time: the required time
		:return: the system species richness
		"""
		if self.database is None:
			raise RuntimeError("Database not set: cannot import richness.")
		else:
			try:
				command = "SELECT species_id FROM SPECIES_ABUNDANCES WHERE no_individuals > 0"
				if speciation_rate is not None:
					command += " AND ROUND(speciation_rate,5) == " + str(round(speciation_rate, 5))
				if time is not None:
					command += " AND generation == " + str(time)
				c = self.cursor.execute(command).fetchall()
				return len(set(c))
			except sqlite3.OperationalError as oe:
				warnings.warn(oe.message)
				warnings.warn("Could not find SPECIES_ABUNDANCES table in database " + self.database)
				return 0
			except sqlite3.OperationalError as e:
				warnings.warn(e.message)
				return 0

	def check_biodiversity_table_exists(self):
		"""
		Checks whether the biodiversity table exists and creates the table if required.
		
		:return: the max reference value currently existing
		"""
		if self.database is None:
			raise RuntimeError("Database has not yet been successfully imported. Can't read database.")
		self.cursor = self.database.cursor()
		tmp_check = "SELECT name FROM sqlite_master WHERE type='table' AND name='BIODIVERSITY_METRICS'"
		tmp_create = "CREATE TABLE BIODIVERSITY_METRICS (ref INT PRIMARY KEY NOT NULL,metric TEXT NOT NULL," \
					 " fragment TEXT NOT NULL, time FLOAT NOT NULL," \
					 "speciation_rate FLOAT NOT NULL, value FLOAT NOT NULL, simulated FLOAT, actual FLOAT)"
		if not self.cursor.execute(tmp_check).fetchone():
			try:
				self.cursor.execute(tmp_create)
				self.database.commit()
			except sqlite3.OperationalError as e:
				raise sqlite3.OperationalError("Error creating biodiversity metric table: " + e.message)
			return 0
		else:
			maxval = self.database.cursor().execute("SELECT MAX(ref) FROM BIODIVERSITY_METRICS").fetchone()[0]
			if maxval is None:
				return 0
			return maxval

	def calculate_richness(self):
		"""
		Calculates the landscape richness from across all fragments and stores result in a new table in
		SPECIES_RICHNESS
		Stores a separate result for each speciation rate and time.
		"""
		if self.database is None:
			raise RuntimeError("Database has not yet been successfully imported. Can't perform calculations.")
		spec_abundances = self.cursor.execute("SELECT * FROM SPECIES_ABUNDANCES WHERE no_individuals>0").fetchall()
		tmp_check = "SELECT name FROM sqlite_master WHERE type='table' AND name='SPECIES_RICHNESS'"
		tmp_create = "CREATE TABLE SPECIES_RICHNESS (ref INT PRIMARY KEY NOT NULL, speciation_rate FLOAT NOT NULL," \
					 "time FLOAT NOT NULL, richness INT NOT NULL)"
		if not self.cursor.execute(tmp_check).fetchone():
			ref = 0
			try:
				self.cursor.execute(tmp_create)
				self.database.commit()
			except Exception as e:
				e.message = "Error creating SPECIES_RICHNESS table: " + e.message
				raise e
		else:
			ref = self.cursor.execute("SELECT COUNT(ref) FROM SPECIES_RICHNESS").fetchone()[0]
		spec_rates = set([x[2] for x in spec_abundances])
		times = set([x[4] for x in spec_abundances])
		output = []
		for t in times:
			for sr in spec_rates:
				select = [x[1] for x in spec_abundances if x[2] == sr and x[4] == t]
				output.append([ref, sr, t, len(select)])
				ref += 1
		ref = self.check_biodiversity_table_exists()
		bio_output = []
		for x in output:
			ref += 1
			tmp = [ref, "whole"]
			tmp.extend(x)
			bio_output.append(tmp)
		self.cursor.executemany("INSERT INTO BIODIVERSITY_METRICS VALUES (?, ?, ?, ?, ?, ?, NULL, NULL)", bio_output)
		self.cursor.executemany("INSERT INTO SPECIES_RICHNESS VALUES(?,?,?,?)", output)
		self.database.commit()

	def get_landscape_richness(self, speciation_rate=None, time=None):
		"""
		Reads the landscape richness from the SPECIES_RICHNESS table in the database. Returns the richness for
		each speciation rate and time.

		Note that this should produce the same result as get_richness(sr, t) with the corresponding sr and t.

		Note that the return type of this function changes based on whether speciation rates and times were supplied.
		If they were, returns a single integer. Otherwise, returns a list of all species richnesses.

		:param speciation_rate: the required speciation rate (optional)
		:param time: the required time
		:return: either a list containing the speciation_rate, time, richness OR (if specific speciation rate and time
		 provided), the species richness at that time and speciation rate.
		:rtype: int, list
		"""
		command = "SELECT speciation_rate, time, richness FROM SPECIES_RICHNESS"
		try:
			richness = self.cursor.execute(command).fetchall()
		except sqlite3.OperationalError as oe:
			oe.message = "Could not get SPECIES_RICHNESS table: " + oe.message
			raise oe
		if speciation_rate is not None and time is not None:
			try:
				# pdb.set_trace()
				# print([x[2] for x in richness if round(x[0],8) == round(speciation_rate, 5) and x[1] == time][0])
				return [x[2] for x in richness if round(x[0], 5) == round(speciation_rate, 5) and x[1] == time][0]
			except IndexError as ie:
				return 0
		return richness

	def calculate_fragment_richness(self):
		"""
		Calculates the fragment richness and stores it in a new table called FRAGMENT_RICHNESS. Also adds the record to
		BIODIVERSITY METRICS for
		If the table already exists, it will simply be returned. Each time point and speciation rate combination will be
		recorded as a new variable.
		"""
		self.cursor = self.database.cursor()
		if self.database is None:
			raise RuntimeError("Database has not yet been successfully imported. Can't perform calculations.")
		tmp_check = "SELECT name FROM sqlite_master WHERE type='table' AND name='FRAGMENT_RICHNESS'"
		tmp_create = "CREATE TABLE FRAGMENT_RICHNESS (ref INT PRIMARY KEY NOT NULL, fragment TEXT NOT NULL," \
					 " time FLOAT NOT NULL, speciation_rate FLOAT NOT NULL, richness INT NOT NULL)"
		# First check the FRAGMENT_ABUNDANCES TABLE EXISTS
		fragments_s = self.cursor.execute("SELECT * FROM FRAGMENT_ABUNDANCES").fetchall()
		# Now try and create FRAGMENT_RICHNESS
		if not self.cursor.execute(tmp_check).fetchone():
			try:
				self.cursor.execute(tmp_create)
				self.database.commit()
			except sqlite3.OperationalError:
				raise sqlite3.OperationalError("Could not create FRAGMENT_RICHNESS table")
			fragment_names = set([f[1] for f in fragments_s])
			self.times = list(set([f[7] for f in fragments_s]))
			self.speciation_rates = list(set([f[5] for f in fragments_s]))
			# self.fragments.extend(([]*len(times)-1))
			ref = 0
			for each in fragment_names:
				for time in self.times:
					for sr in self.speciation_rates:
						selection = [row for row in fragments_s if row[1] == each and row[7] == time and row[5] == sr]
						self.fragments.append([ref, each, time, sr, len(selection)])
						ref += 1
			self.cursor.executemany("INSERT INTO FRAGMENT_RICHNESS VALUES(?, ?, ?, ?, ?)", self.fragments)
			self.database.commit()
		else:
			self.fragments = self.cursor.execute("SELECT * FROM FRAGMENT_RICHNESS").fetchall()
			# Move fragment richnesses into BIODIVERSITY METRICS
			ref = self.check_biodiversity_table_exists()
			tmp_fragments = []
			for x in self.fragments:
				ref += 1
				tmp = [ref]
				tmp.extend(x)
				tmp_fragments.append(tmp)
			self.cursor.executemany("INSERT INTO BIODIVERSITY_METRICS VALUES(?,?,?,?,?,?, NULL, NULL)", tmp_fragments)
		self.database.commit()
		self.calculate_richness()

	def generate_biodiversity_metrics(self):
		"""
		Generates the biodiversity metrics table, adding in any calculations from the tables FRAGMENT_RICHNESS and
		FRAGMENT_OCTAVES.

		Note that this function calls calculate_octaves_error() and calculate_fragment_richness() when required.
		"""
		# TODO finish this implementation
		if len(self.fragments) is 0:
			try:
				self.calculate_fragment_richness()
			except sqlite3.OperationalError:
				logging.warning("Skipping fragments as no fragment abundances could be found.")
		# First check that the biodiversity table exists
		ref = self.check_biodiversity_table_exists() + 1
		# Need to check again to see if calculate_fragment_richness() was successful
		if len(self.fragments) is not 0:
			# Move fragment richnesses into BIODIVERSITY METRICS

			self.cursor = self.database.cursor()
			# self.cursor.execute()
			tmp_fragments = []
			tmp_fragments = [[ref+i].extend(x) for i, x in enumerate(self.fragments)]
			# print(tmp_fragments)
			self.cursor.executemany("INSERT INTO BIODIVERSITY_METRICS VALUES(?,?,?,?,?,?, NULL, NULL)", tmp_fragments)
		# Now check if fragment octaves errors have been calculated.
		try:
			self.calculate_octaves_error()
		except (sqlite3.OperationalError, RuntimeError):
			logging.warning("Skippping fragment octaves as no fragment octaves could be calculated")
		self.database.commit()

	def import_comparison_data(self, filename):
		"""
		Imports the SQL database that contains the biodiversity metrics that we want to compare against.

		This can either be real data (for comparing simulated data) or other simulated data (for comparing between models).

		If the SQL database does not contain the relevant biodiversity metrics, they will be calculated (if possible) or skipped.

		The expected form of the database is the same as the BIODIVERSITY_METRICS table, except without any speciation
		rates or time references, and a new column containing the number of individuals involved in each metric.

		:param str filename: the file containing the comparison biodiversity metrics.
		"""
		conn = sqlite3.connect(filename)
		tmp_cursor = conn.cursor()
		if self.comparison_file is not None:
			warnings.warn("Comparison data has already been imported.")
		try:
			self.comparison_data = tmp_cursor.execute("SELECT * FROM BIODIVERSITY_METRICS").fetchall()
			try:
				self.comparison_abundances = tmp_cursor.execute(
					"SELECT Plot, Mnemonic, Abund FROM FRAGMENT_ABUNDANCES").fetchall()
				self.comparison_abundances_whole = tmp_cursor.execute(
					"SELECT SpeciesID, Abund FROM SPECIES_ABUNDANCES").fetchall()
			except sqlite3.OperationalError as oe:
				oe.message += "Problem executing fetches from comparison data: "
				raise oe
			self.comparison_file = filename
		except sqlite3.OperationalError as oe:
			print(oe.message)
			raise RuntimeError("Could not import from comparison data.")
		# print(self.comparison_data)
		# exit(0)

	def calculate_comparison_octaves(self, store=False):
		"""
		Calculates the octave classes for the comparison data and for fragments (if required).
		If the octaves exist in the FRAGMENT_OCTAVES table in the comparison database, the data will be imported
		instead of being re-calculated.
		Stores the new octave classes in self.comparison_octaves.

		:param store: if True, stores within the comparison database.

		"""
		if self.comparison_octaves is None:
			# If comparison_octaves has not been calculated, then do that now.
			if self.comparison_abundances is None:
				warnings.warn(
					"Comparison abundances not yet imported, or FRAGMENT_ABUNDANCES does not exist in comparison file.")
			# Check whether the FRAGMENT_OCTAVES table exists, if it is, just stored that in self.comparison_octaves
			if self.comparison_file is not None:
				# read the data from the database
				db = sqlite3.connect(self.comparison_file)
				c = db.cursor()
				tmp = c.execute(
					"SELECT * FROM sqlite_master WHERE name ='FRAGMENT_OCTAVES' and type='table'").fetchall()
				if len(tmp) is 1:
					tmp_list = c.execute("SELECT fragment, octave, num_species FROM FRAGMENT_OCTAVES").fetchall()
					if len(tmp_list) > 0:
						self.comparison_octaves = tmp_list
						store = False
			# Otherwise, if comparison abundances exists, we can calculate the comparison octaves manually
			if self.comparison_abundances is not None and self.comparison_octaves is None:
				# now calculate octaves
				self.comparison_octaves = []
				ref = 0
				fragments = set([x[0] for x in self.comparison_abundances])
				for f in fragments:
					octaves = [[], []]
					octaves[0] = []
					octaves[1] = []
					abundances = [x for x in self.comparison_abundances if str(x[0]) == f]
					# print(abundances)
					# exit(0)
					for each in abundances:
						this_octave = int(math.floor(math.log(each[2], 2)))
						if this_octave in octaves[0]:
							pos = [i for i, x in enumerate(octaves[0]) if x == this_octave]
							# print(octaves)
							self.comparison_octaves[octaves[1][pos[0]]][2] += 1
						else:
							self.comparison_octaves.append([str(f), this_octave, 1])
							# print(self.comparison_octaves)
							octaves[0].append(this_octave)
							octaves[1].append(ref)
							ref += 1
						# print(len(self.comparison_octaves)-1)
				octaves = [[], []]
				octaves[0] = []
				octaves[1] = []
				abundances = self.comparison_abundances_whole
				# print(abundances)
				# exit(0)
				for each in abundances:
					this_octave = int(math.floor(math.log(each[1], 2)))
					if this_octave in octaves[0]:
						pos = [i for i, x in enumerate(octaves[0]) if x == this_octave]
						# print(octaves)
						self.comparison_octaves[octaves[1][pos[0]]][2] += 1
					else:
						self.comparison_octaves.append(["whole", this_octave, 1])
						# print(self.comparison_octaves)
						octaves[0].append(this_octave)
						octaves[1].append(ref)
						ref += 1
					# now sort the list
					# self.comparison_octaves.sort(key=lambda x: x[0])
			# If we want to store the comparison octaves, overwrite the original FRAGMENT_OCTAVES table (if it exists
			# with the new calculated data
			if store:
				if self.comparison_file is None:
					# this error should never be thrown.
					raise RuntimeError("Comparison file has not been imported yet, and therefore cannot be written to.")
				conn = sqlite3.connect(self.comparison_file)
				cursor = conn.cursor()
				cursor.execute("DROP TABLE IF EXISTS FRAGMENT_OCTAVES")
				cursor.execute(
					"CREATE TABLE FRAGMENT_OCTAVES (ref INT PRIMARY KEY NOT NULL, fragment TEXT NOT NULL, "
					"octave INT NOT NULL, num_species INT NOT NULL)")
				cursor.executemany("INSERT INTO FRAGMENT_OCTAVES values(?,?,?,?)",
								   [[i, x[0], x[1], x[2]] for i, x in enumerate(self.comparison_octaves)])
				conn.commit()

	def calculate_octaves(self):
		"""
		Calculates the octave classes for the landscape. Outputs the calculated richness into the SQL database within a
		FRAGMENT_OCTAVES table.

		"""
		if self.database is None:
			raise RuntimeError("Database has not yet been successfully imported. Can't perform calculations.")
		self.cursor = self.database.cursor()
		self.cursor.execute(
			"CREATE TABLE IF NOT EXISTS FRAGMENT_OCTAVES (ref INT PRIMARY KEY NOT NULL, fragment TEXT NOT NULL, "
			"time FLOAT NOT NULL, speciation_rate FLOAT NOT NULL, octave INT NOT NULL, "
			"number INT NOT NULL)")
		abundances = self.cursor.execute("SELECT * FROM SPECIES_ABUNDANCES WHERE no_individuals>0").fetchall()
		spec_rates = set([x[2] for x in abundances])
		times = set([x[4] for x in abundances])
		# Check what the maximum reference is in FRAGMENT_OCTAVES
		try:
			c = self.cursor.execute("SELECT max(ref) FROM FRAGMENT_OCTAVES").fetchone()[0] +1
		except (sqlite3.OperationalError, TypeError):
			c = 0
		for s in spec_rates:
			for t in times:
				select_abundances = [x[3] for x in abundances if round(x[2], 2) == round(s, 2) and x[4] == t]
				log_select = [math.floor(math.log(x, 2)) for x in select_abundances]
				out = []
				try:
					for i in range(0, int(max(log_select)), 1):
						tot = log_select.count(i)
						out.append([c, "whole", t, s, i, tot])
						c += 1
				except ValueError as ve:
					raise ve
				try:
					self.cursor.executemany("INSERT INTO FRAGMENT_OCTAVES values (?,?,?,?,?,?)", out)
				except sqlite3.OperationalError as oe:
					raise sqlite3.OperationalError("Could not insert into FRAGMENT_OCTAVES." + str(oe))

	def calculate_fragment_octaves(self):
		"""
		Calculates the octave classes for each fragment. Outputs the calculated richness into the SQL database within a
		FRAGMENT_OCTAVES table
		"""
		if self.database is None:
			raise RuntimeError("Database has not yet been successfully imported. Can't perform calculations.")
		self.cursor = self.database.cursor()
		self.cursor.execute(
			"CREATE TABLE IF NOT EXISTS FRAGMENT_OCTAVES (ref INT PRIMARY KEY NOT NULL, fragment TEXT NOT NULL, "
			"time FLOAT NOT NULL, speciation_rate FLOAT NOT NULL, octave INT NOT NULL, "
			"number INT NOT NULL)")
		exist_check = self.cursor.execute("SELECT * FROM FRAGMENT_OCTAVES").fetchall()
		if exist_check:
			raise RuntimeError("FRAGMENT_OCTAVES already exists")
		abundances = self.cursor.execute("SELECT * FROM FRAGMENT_ABUNDANCES").fetchall()
		fragments = set([x[1] for x in abundances])
		spec_rates = set([x[5] for x in abundances])
		times = set([x[7] for x in abundances])
		c = 0
		for f in fragments:
			for s in spec_rates:
				for t in times:
					select_abundances = [x[6] for x in abundances if x[1] == f and x[5] == s and x[7] == t]
					log_select = [math.floor(math.log(x, 2)) for x in select_abundances]
					out = []
					for i in range(0, int(max(log_select)), 1):
						tot = log_select.count(i)
						out.append([c, f, t, s, i, tot])
						c += 1
					try:
						self.cursor.executemany("INSERT INTO FRAGMENT_OCTAVES values (?,?,?,?,?,?)", out)
					except sqlite3.OperationalError as oe:
						raise sqlite3.OperationalError("Could not insert into FRAGMENT_OCTAVES." + str(oe))
		self.database.commit()
		self.calculate_octaves()

	def get_fragment_richness(self, fragment=None, speciation_rate=None, time=0.0):
		"""
		Gets the fragment richness for each speciation rate and time for the specified simulation. If the fragment
		richness has not yet been calculated, it tries to calculate the fragment richness,


		:param fragment: the desired fragment (defaults to None)
		:param speciation_rate: the desired speciation rate (defaults to None)
		:param time: the desired generation time (defaults to 0.0)

		:raises: sqlite3.OperationalError if no table FRAGMENT_ABUNDANCES exists
		:raises: RuntimeError if no data for the specified fragment, speciation rate and time exists.
		:return: A list containing the fragment richness
		"""
		if self.database is None:
			raise RuntimeError("Database has not yet been successfully imported. Can't perform calculations.")
		if fragment is None and speciation_rate is None:
			if len(self.fragments) is 0:
				self.calculate_fragment_richness()
			return self.fragments
		elif fragment is None or speciation_rate is None:
			raise SyntaxError("Only one of fragment or speciation rate supplied: must supply both, or neither.")
		select_statement = "SELECT * FROM FRAGMENT_RICHNESS WHERE time == " + str(time) + \
		                   " and fragment == '" + fragment + "'"
		output = self.cursor.execute(select_statement).fetchall()
		if len(output) == 0:
			raise RuntimeError("No output while fetching fragment data: " + select_statement)
		else:
			fragment_richness = [list(x) for x in output if x[3] == speciation_rate]
			return fragment_richness[0]

	def get_fragment_octaves(self, fragment=None, speciation_rate=None, time=0.0):
		"""
		Get the pre-calculated octave data for the specified fragment, speciation rate and time. If fragment and
		speciation_rate are None, returns the entire FRAGMENT_OCTAVES object
		This requires self.calculate_fragment_octaves() to have been run successfully at some point previously.

		:param fragment: the desired fragment (defaults to None)
		:param speciation_rate: the desired speciation rate (defaults to None)
		:param time: the desired generation time (defaults to 0.0)
		:return: output from FRAGMENT_OCTAVES for the selected variables
		"""
		self.cursor = self.database.cursor()
		if self.database is None:
			raise RuntimeError("Database has not yet been successfully imported. Can't perform calculations.")
		if fragment is None and speciation_rate is None:
			return [list(x) for x in self.cursor.execute("SELECT * FROM FRAGMENT_OCTAVES")]
		elif fragment is None or speciation_rate is None:
			raise SyntaxError("Only one of fragment or speciation rate supplied: must supply both, or neither.")
		select_statement = "SELECT * FROM FRAGMENT_OCTAVES WHERE time == " + str(time) + \
		                   " and fragment == '" + fragment + "'"
		## Hacky way to get around SQL's float-rounding issues.
		try:
			output = self.cursor.execute(select_statement).fetchall()
			if len(output) == 0:
				raise RuntimeError("No output while fetching fragment data: " + select_statement)
			else:
				output = [list(x) for x in output if x[3] == speciation_rate]
		except sqlite3.OperationalError as oe:
			raise sqlite3.OperationalError("Failure whilst fetching fragment octave data." + str(oe))
		output.sort(key=lambda x: x[4])
		return output

	def calculate_octaves_error(self):
		"""
		Calculates the error in octaves classes between the simulated data and the comparison data.
		Stores each error value as a new entry in BIODIVERSITY_METRICS under fragment_octaves.
		Calculates the error by comparing each octave class and summing the relative difference.
		Octaves are then averaged for each fragment.
		"""
		# TODO write test cases for this, it looks a mess
		if self.comparison_octaves is None:
			try:
				self.calculate_comparison_octaves()
			except Exception as exc:
				print(exc.message)
				raise RuntimeError("Comparison octaves has not been generated. Check calculate_comparison_octaves"
								   " has been successful.")
		self.cursor = self.database.cursor()
		if self.database is None:
			raise RuntimeError("Database has not yet been successfully imported. Can't perform calculations.")
		try:
			data = self.cursor.execute("SELECT fragment, time, speciation_rate FROM FRAGMENT_OCTAVES").fetchall()
		except sqlite3.OperationalError:
			self.calculate_fragment_octaves()
		else:
			if len(data) == 0:
				self.calculate_fragment_octaves()
		try:
			self.cursor.execute("ALTER TABLE FRAGMENT_OCTAVES ADD COLUMN comparison float")
			self.cursor.execute("ALTER TABLE FRAGMENT_OCTAVES ADD COLUMN error float")
			col_add = True
		except sqlite3.OperationalError as soe:
			raise sqlite3.OperationalError("Could not alter FRAGMENT_OCTAVES table: " + str(soe))
		fragments = set([x[0] for x in data])
		times = set([x[1] for x in data])
		spec_rates = set([x[2] for x in data])
		fragment_errors = []
		ref = self.check_biodiversity_table_exists()
		fragment_sql = []
		frag_ref = len(data)
		for f in fragments:
			for t in times:
				for s in spec_rates:
					octaves = self.get_fragment_octaves(f, s, t)
					comparison_octaves = [x for x in self.comparison_octaves if x[0] == f]
					try:
						maxval = max(max([x[4] for x in octaves]), max([x[1] for x in comparison_octaves]))
					except ValueError:
						try:
							maxval = max([x[1] for x in comparison_octaves])
						except ValueError:
							try:
								maxval = max([x[4] for x in octaves])
							except ValueError:
								maxval = 0
					difference = []
					for i in range(0, maxval, 1):
						try:
							oct_val, ref_val = [[x[5], x[0]] for x in octaves if x[4] == i][0]
						except (ValueError, IndexError):
							difference.append(1.0)
							continue
						try:
							comp_val = [x[2] for x in comparison_octaves if x[1] == i][0]
						except (ValueError, IndexError):
							difference.append(1.0)
						else:
							## The error is calculated as
							difference.append(
								float(max(oct_val, comp_val) - min(oct_val, comp_val)) / max(comp_val, oct_val))
						if col_add:
							self.cursor.execute(
								"UPDATE FRAGMENT_OCTAVES SET comparison = {0}, error = {1} WHERE ref == {2}".format(
									str(comp_val), str(difference[-1]), str(ref_val)))
					# now average the errors
					ref += 1
					fragment_errors.append(
						[ref, "fragment_octaves", f, t, s, float(sum(difference) / float(len(difference)))])

		self.cursor.executemany("INSERT INTO BIODIVERSITY_METRICS VALUES(?,?,?,?,?,?, NULL, NULL)", fragment_errors)
		self.database.commit()

	def calculate_goodness_of_fit(self):
		"""
		Calculates the goodness-of-fit measure based on the calculated biodiversity metrics, scaling each metric by the
		number of individuals involved in the metric.

		This requires that import_comparison_data() has already been successfully run.

		Note that this doesn't calculate anything for values which have not yet been written to the SQL database -
		make sure that the relevant save functions have been run already.

		The resulting value will then be written to the BIODIVERSITY_METRICS table in the SQL database.
		"""
		## check that the comparison data has already been imported.
		if self.comparison_data is None:
			raise RuntimeError("Comparison data not yet imported.")

		self.cursor = self.database.cursor()
		bio_metrics = self.cursor.execute(
			"SELECT * FROM BIODIVERSITY_METRICS WHERE metric != 'goodness_of_fit'").fetchall()
		self.total_individuals = \
			self.cursor.execute("SELECT COUNT(tip) FROM SPECIES_LIST WHERE tip==1 AND gen_added==0.0").fetchone()[0]
		# print(self.total_individuals)
		# exit(1)
		try:
			self.cursor.execute("ALTER TABLE FRAGMENT_OCTAVES ADD COLUMN comparison float")
			self.cursor.execute("ALTER TABLE FRAGMENT_OCTAVES ADD COLUMN error float")
		except sqlite3.OperationalError:
			pass

		# Remove the extra goodness of fit values
		bio_metrics = [b for b in bio_metrics if 'goodness_of_fit' not in b[1]]
		# this will contain: metric, fragment, time, spec, relative_goodness_of_fit, num_individuals, simulated, actual
		goodness_of_fit = []
		# generate the connection for the plot data
		db = sqlite3.connect(self.comparison_file)
		c = db.cursor()
		plot_data = c.execute("SELECT fragment, plotID, number_individuals FROM PLOT_DATA").fetchall()
		for each in bio_metrics:
			if each[1] != "fragment_octaves":
				try:
					comparison = [f for f in self.comparison_data if f[0] == each[1] and f[1] == each[2]][0]
				except IndexError:
					logging.warning('Could not find comparable metric for ' + str(each[1]) + ' and ' + str(each[2]))
					continue
				scaled_fit = (max(comparison[2], each[5]) - min(comparison[2], each[5])) / max(comparison[2], each[5])
				name = each[1]
				fragment = comparison[1]
				self.cursor.execute(
					"UPDATE BIODIVERSITY_METRICS SET simulated = {0}, actual = {1}, value={2} WHERE ref == {3}".format(
						str(each[5]), str(comparison[2]), str(scaled_fit), str(each[0])))
			# sim = "NULL"
			# actual = "NULL"
			else:
				try:
					comparison = [f for f in plot_data if f[0] == each[2]][0]
					comparison = [x for x in comparison]
					comparison.append(None)
					name = "fragment_octaves"
					fragment = comparison[0]
				# sim = "NULL"
				# actual = "NULL"
				except IndexError:
					print('Could not find reference metric for ' + str(each[1]) + ' and ' + str(each[2]))
					continue
				scaled_fit = each[5]
			# print(each)
			# print(comparison)
			## Each metric will later be scaled so that the value is proportional to the number of individuals involved

			goodness_of_fit.append(
				[name, fragment, each[3], each[4], scaled_fit, comparison[2], each[5], comparison[3]])
		# Sum the fit values
		self.speciation_rates = list(set([f[4] for f in bio_metrics]))
		self.times = list(set([f[3] for f in bio_metrics]))
		sum_fits = []
		# Also get the fits for each category
		categories = list(set([f[0] for f in goodness_of_fit]))
		# print(categories)
		for time in self.times:
			for sr in self.speciation_rates:
				for c in categories:
					total = sum([g[5] for g in goodness_of_fit if g[2] == time and g[3] == sr and g[0] == c])
					sum_fits.append([time, sr, c, total])
		# Find the relative goodness of fits for each metric
		for i, each in enumerate(goodness_of_fit):
			# print(each)
			s = [n[3] for n in sum_fits if n[0] == each[2] and n[1] == each[3] and n[2] == each[0]][0]
			goodness_of_fit[i][4] = ((each[4] * each[5]) / s)
		# pdb.set_trace()
		goodness_SQL = []
		ref = self.check_biodiversity_table_exists()
		for time in self.times:
			for sr in self.speciation_rates:
				## 1- value so that we get a value range with perfect fitting at 1.
				# value = 1 - sum([g[4] for g in goodness_of_fit if g[2] == time and g[3] == sr])
				# ref += 1
				for c in categories:
					values = [g[4] for g in goodness_of_fit if g[2] == time and
							  g[3] == sr and g[0] == c]
					# print(values)
					value = 1 - sum([x for x in values])
					# simulated = values[0][1]
					# actual = values[0][2]
					name = "goodness_of_fit_" + c
					ref += 1
					goodness_SQL.append([ref, name, "whole", time, sr, value, None, None])
		for time in self.times:
			for sr in self.speciation_rates:
				value = sum([g[5] for g in goodness_SQL if g[3] == time and g[4] == sr]) / 3
				ref += 1
				goodness_SQL.append([ref, "goodness_of_fit", "whole", time, sr, value, None, None])
		self.cursor = self.database.cursor()
		self.cursor.executemany("INSERT INTO BIODIVERSITY_METRICS values(?,?,?,?,?,?, ?, ?)", goodness_SQL)
		self.database.commit()

	def get_species_list(self):
		"""
		Gets the entirety of the SPECIES_LIST table, returning a tuple with an entry for each row. This can be used to
		construct custom analyses of the coalescence tree.

		.. note::

			The species list will be produced in an unprocessed format, with

		:return: a list of each coalescence and speciation event, with locations, performed in the simulation
		:rtype: tuple
		"""
		try:
			self.cursor = self.database.cursor()
		except AttributeError as ae:
			raise RuntimeError("Database has not been set: " + ae.message)
		return self.cursor.execute("SELECT * FROM SPECIES_LIST").fetchall()

	def get_goodness_of_fit(self, fragment=None, speciation_rate=None, time=0.0):
		"""
		Returns the goodness of fit from the file.

		:return: the full output from the SQL query
		:rtype: list
		"""
		if self.check_biodiversity_table_exists() == 0:
			raise RuntimeError("Biodiversity table does not contain any values.")
		else:
			self.cursor = self.database.cursor()
			ret = self.cursor.execute(
				"SELECT * FROM BIODIVERSITY_METRICS WHERE fragment=='whole' and metric=='goodness_of_fit'").fetchall()
			if len(ret) is 0:
				raise RuntimeError("Biodiversity table does not contain goodness-of-fit values.")
			else:
				return ret

	def get_goodness_of_fit_fragment_richness(self):
		"""
		Returns the goodness of fit for fragment richness from the file.

		Note that no error will be thrown if the table doesn't exist, just an empty list returned.
		This improves compatibility of functions that call this one.

		:return: the full output from the SQL query
		:rtype: list
		"""
		if self.check_biodiversity_table_exists() == 0:
			raise RuntimeError("Biodiversity table does not contain any values.")
		else:
			self.cursor = self.database.cursor()
			ret = self.cursor.execute(
				"SELECT * FROM BIODIVERSITY_METRICS WHERE fragment=='whole' and metric=='goodness_of_fit_fragment_richness'").fetchall()
			return ret

	def get_goodness_of_fit_fragment_octaves(self):
		"""
		Returns the goodness of fit for fragment octaves from the file.

		Note that no error will be thrown if the table doesn't exist, just an empty list returned.
		This improves compatibility of functions that call this one.

		:return: the full output from the SQL query
		:rtype: list
		"""
		if self.check_biodiversity_table_exists() == 0:
			raise RuntimeError("Biodiversity table does not contain any values.")
		else:
			self.cursor = self.database.cursor()
			ret = self.cursor.execute(
				"SELECT * FROM BIODIVERSITY_METRICS WHERE fragment=='whole' and metric=="
				"'goodness_of_fit_fragment_octaves'").fetchall()
			return ret

	def dispersal_parameters(self):
		"""
		Reads the dispersal parameters from the database and returns them.

		:return: a list of the dispersal parameters [zfat, L-value]
		"""
		ret = self.get_simulation_parameters()
		return [ret[4], ret[5]]

	def get_job(self):
		"""
		Gets the job number (the seed) and the job type (task number).

		:return: list containing [job_number (seed), job_type (task number)]
		"""
		ret = self.get_simulation_parameters()
		return [ret[0], ret[1]]

	def get_simulation_parameters(self):
		"""
		Reads the simulation parameters from the database and returns them.
		:return: a list of the simulation parameters [seed, job_type, output_dir, spec_rate, zfat, L_value, deme,
		sample_size, maxtime, lambda, min_spec, forest_change, time_since_pristine, time_config, coarse_map vars,
		fine map vars, sample_file, gridx, gridy, pristine coarse map, pristine fine map]

		"""
		self.cursor = self.database.cursor()
		try:
			self.cursor.execute("SELECT job_num, job_type, output_dir, spec_rate, zfat, dispersal, deme, sample_size, "
								"max_time, lambda, min_num_species, forest_change_param, time_since_pristine, "
								"time_config_file, coarse_map_file, coarse_map_x, coarse_map_y, coarse_map_x_offset, "
								"coarse_map_y_offset, coarse_map_scale, fine_map_file, fine_map_x, fine_map_y, "
								"fine_map_x_offset, fine_map_y_offset, sample_file, grid_x, grid_y, pristine_coarse_map, "
								" pristine_fine_map, sim_complete FROM SIMULATION_PARAMETERS")
		except sqlite3.OperationalError as e:
			e.message = "Failure to get SIMULATION_PARAMETERS table from database. Check table exists." + e.message
			raise e
		ret = [x for x in self.cursor.fetchone()]
		# Convert unicode strings to pythonic strings
		if sys.version_info[0] is not 3:
			for i, each in enumerate(ret):
				if isinstance(each, unicode):
					ret[i] = each.encode('ascii')
		return [x for x in ret]

	def is_completed(self):
		"""
		Indicates whether the simulation has been performed to completion, or if the simulation has been paused and
		needs to be completed before analysis can be performed.
		:return: bool: true if simulation is complete
		"""
		return self.is_complete

	def clear_calculations(self):
		"""
		Removes the BIODIVERSITY_METRICS and FRAGMENT_OCTAVES tables completely.
		Note that this cannot be undone (other than re-running the calculations).
		"""
		self.cursor = self.database.cursor()
		self.cursor.execute('DROP TABLE IF EXISTS BIODIVERSITY_METRICS')
		self.cursor.execute('DROP TABLE IF EXISTS FRAGMENT_OCTAVES')
		self.cursor.execute('DROP TABLE IF EXISTS PLOT_DATA')
		self.database.commit()

	def wipe_data(self):
		"""
		Wipes all calculated data apart from the original, unformatted coalescence tree.
		The Speciation_Counter program will have to be re-run to perform any analyses.
		"""
		self.cursor = self.database.cursor()
		self.cursor.execute("DROP TABLE IF EXISTS FRAGMENT_ABUNDANCES")
		self.cursor.execute("DROP TABLE IF EXISTS SPECIES_ABUNDANCES")
		self.cursor.execute("DROP TABLE IF EXISTS SPECIES_LOCATIONS")
		self.cursor.execute("DROP TABLE IF EXISTS BIODIVERSITY_METRICS")
		self.cursor.execute("DROP TABLE IF EXISTS FRAGMENT_OCTAVES")
		self.database.commit()


def collate_fits(file_dir, filename="Collated_fits.db"):
	"""
	Collates the goodness of fit values from every file in the specified directory and places them in one new file.
	Note that files with 'collated' in the name will be ignored.
	Note that if the output file exists, it will be deleted.

	Creates three separate tables in the output file, one for overall goodness of fit, one for fragment richness fits,
	and one for fragment octaves fits.
	:param file_dir: the file directory to examine
	:param filename: [optional] the output file name.
	"""
	if filename == "Collated_fits.db":
		filename = os.path.join(file_dir, filename)
	if os.path.exists(filename):
		os.remove(filename)

	try:
		database = sqlite3.connect(filename)
	except Exception as e:
		raise IOError("Error opening SQLite database: " + e.message)
	database.execute("CREATE TABLE GOODNESS_FIT (ref INT PRIMARY KEY NOT NULL, task INT NOT NULL, seed INT NOT NULL, "
					 "zfat FLOAT NOT NULL, dispersal FLOAT NOT NULL," \
					 "time FLOAT NOT NULL, speciation_rate FLOAT NOT NULL, value FLOAT NOT NULL)")
	database.execute(
		"CREATE TABLE GOODNESS_FIT_FRAGMENT_RICHNESS (ref INT PRIMARY KEY NOT NULL, task INT NOT NULL, seed INT NOT NULL, "
		"zfat FLOAT NOT NULL, dispersal FLOAT NOT NULL," \
		"time FLOAT NOT NULL, speciation_rate FLOAT NOT NULL, value FLOAT NOT NULL)")
	database.execute(
		"CREATE TABLE GOODNESS_FIT_FRAGMENT_OCTAVES (ref INT PRIMARY KEY NOT NULL, task INT NOT NULL, seed INT NOT NULL, "
		"zfat FLOAT NOT NULL, dispersal FLOAT NOT NULL," \
		"time FLOAT NOT NULL, speciation_rate FLOAT NOT NULL, value FLOAT NOT NULL)")
	ref = 0
	ref_richness = 0
	ref_octaves = 0
	out = []
	out_richness = []
	out_octaves = []
	if os.path.exists(file_dir):
		for file in os.listdir(file_dir):
			if os.path.join(file_dir, file) == filename or "Collated" in file:
				continue
			elif ".db" in file and os.path.isfile(os.path.join(file_dir, file)):
				temp = Tree()
				temp.set_database(os.path.join(file_dir, file))
				try:
					gof = temp.get_goodness_of_fit()
				except:
					raise RuntimeError("File: " + file)
				gof_octaves = temp.get_goodness_of_fit_fragment_octaves()
				gof_richness = temp.get_goodness_of_fit_fragment_richness()
				disp = temp.dispersal_parameters()
				j = temp.get_job()
				for each in gof:
					out.append([ref, j[0], j[1], disp[0], disp[1], each[3], each[4], each[5]])
					ref += 1
				for each in gof_richness:
					out_richness.append([ref_richness, j[0], j[1], disp[0], disp[1], each[3], each[4], each[5]])
					ref_richness += 1
				for each in gof_octaves:
					out_octaves.append([ref_octaves, j[0], j[1], disp[0], disp[1], each[3], each[4], each[5]])
					ref_octaves += 1
		database.executemany("INSERT INTO GOODNESS_FIT values(?,?,?,?,?,?,?,?)", out)
		database.executemany("INSERT INTO GOODNESS_FIT_FRAGMENT_RICHNESS values(?,?,?,?,?,?,?,?)", out_richness)
		database.executemany("INSERT INTO GOODNESS_FIT_FRAGMENT_OCTAVES values(?,?,?,?,?,?,?,?)", out_octaves)
		database.commit()
	else:
		raise RuntimeError("Specified file directory " + file_dir + " does not exist")
