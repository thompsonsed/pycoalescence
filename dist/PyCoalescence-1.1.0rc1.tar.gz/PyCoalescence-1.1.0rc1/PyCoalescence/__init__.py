"""
PyCoalescence Package provides the facilities for running spatially-explicit neutral coalescence ecological simulations
and performing basic analysis of the simulation outputs. The program requires the NECSim program to function properly,
which will be included in the package at a later date.

"""

from coalescence import Coalescence, Map
from coal_analyse import Tree
import setup

