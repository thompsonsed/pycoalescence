"""
Sets up the code for the hpc and moves the executable to the correct directory.
"""

import logging

try:
	import PyCoalescence.setup as setup
	from PyCoalescence.system_operations import set_logging_method
except ImportError:
	import setup
	from system_operations import set_logging_method


def build_hpc():
	"""
	Compiles NECSim with the ``--with-hpc``, ``--with-verbose`` and ``--with-fat_tail_dispersal`` flags, and moves the
	executable to ../../Code/ relative to the file location.
	:return:
	"""
	set_logging_method(logging_level=logging.INFO)
	setup.clean()
	setup.configure(["--with-hpc", "--with-verbose", "--with-fat_tail_dispersal"])
	setup.do_compile()
	setup.move_executable(directory="../../Code/")


if __name__ == "__main__":
	build_hpc()
